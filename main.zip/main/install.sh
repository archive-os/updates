#!/usr/bin/env bash
set -Eeuo pipefail
bundle_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
if [[ ${1:-} == --dry-run || ${1:-} == --help ]]; then
    exec /usr/bin/python3 -u "$bundle_dir/helpers/update.py" --bundle "$bundle_dir" "$@"
fi
if (( EUID != 0 )); then
    exec sudo -- /usr/bin/python3 -u "$bundle_dir/helpers/update.py" --bundle "$bundle_dir" "$@"
fi
exec /usr/bin/python3 -u "$bundle_dir/helpers/update.py" --bundle "$bundle_dir" "$@"
