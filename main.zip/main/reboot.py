#!/usr/bin/python3
"""Standalone ArchiveOS restart prompt. Requires python3-pyqt6.

Run as the desktop user. --preview FILE renders without permitting a reboot.
"""
import argparse
import configparser
import os
import sys
from pathlib import Path

from PyQt6.QtCore import QLocale, QProcess, QTimer, Qt, QStandardPaths
from PyQt6.QtGui import QIcon, QPalette, QPixmap
from PyQt6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel,
                             QPushButton, QVBoxLayout)

LOGO = next((str(p) for p in (Path('/usr/share/icons/Aos/aos-menu.png'), Path(__file__).parent/'helpers/aos-menu.png', Path(__file__).parent/'aos-menu.png') if p.is_file()), '')
TEXT = {
    'tr': ('Güncelleme tamamlandı', 'Yeniden başlatılsın mı?',
           'Değişikliklerin uygulanması için bilgisayarınızı yeniden başlatın.',
           'Daha sonra', 'Yeniden başlat', 'Yeniden başlatılıyor…',
           'Yeniden başlatma isteği gönderilemedi. Lütfen tekrar deneyin.'),
    'en': ('Update complete', 'Restart now?',
           'Restart your computer to apply the changes.',
           'Later', 'Restart now', 'Restarting…',
           'Could not request a restart. Please try again.'),
}


def system_language():
    for key in ('LC_ALL', 'LC_MESSAGES', 'LANGUAGE', 'LANG'):
        value = os.environ.get(key, '').split(':')[0]
        if value:
            return 'tr' if value.lower().split('_')[0].split('-')[0] == 'tr' else 'en'
    return 'tr' if QLocale.system().name().startswith('tr') else 'en'


def system_theme(app):
    root=Path(os.environ.get('XDG_CONFIG_HOME',str(Path.home()/'.config')))
    paths=[root/'kdeglobals',root/'kdedefaults/kdeglobals']
    paths.extend(Path(folder)/'kdeglobals' for folder in os.environ.get('XDG_CONFIG_DIRS','/etc/xdg').split(':') if folder)
    for path in paths:
        config=configparser.ConfigParser(interpolation=None,strict=False)
        try:
            config.read(path,encoding='utf-8')
            value=config.get('Colors:Window','BackgroundNormal',fallback='')
            if not value:
                scheme=config.get('General','ColorScheme',fallback='')
                filename=QStandardPaths.locate(QStandardPaths.StandardLocation.GenericDataLocation,'color-schemes/'+Path(scheme).name+'.colors') if scheme else ''
                if filename:
                    colors=configparser.ConfigParser(interpolation=None,strict=False);colors.read(filename,encoding='utf-8')
                    value=colors.get('Colors:Window','BackgroundNormal',fallback='')
                if not value and scheme:
                    if 'dark' in scheme.lower():return 'dark'
                    if any(word in scheme.lower() for word in ('light','white')):return 'light'
            rgb=[int(v) for v in value.split(',')[:3]] if value else []
            if len(rgb)==3 and all(0<=v<=255 for v in rgb):
                return 'dark' if sum(a*b for a,b in zip(rgb,(.2126,.7152,.0722)))<128 else 'light'
        except (OSError,ValueError,configparser.Error):pass
    return 'dark' if app.palette().color(QPalette.ColorRole.Window).lightness()<128 else 'light'


class RebootDialog(QDialog):
    def __init__(self, lang, theme, preview=False, request_only=False):
        super().__init__()
        self.words = TEXT[lang]
        self.preview = preview
        self.request_only = request_only
        self.process = None
        self.setWindowTitle('ArchiveOS · ' + self.words[0])
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint,True)
        self.setWindowIcon(QIcon(LOGO))
        self.setMinimumWidth(510)
        dark = theme == 'dark'
        bg, fg, muted, border, button, hover = (
            ('#101010', '#f5f5f5', '#b5b5b5', '#444444', '#242424', '#363636') if dark else
            ('#fafafa', '#171717', '#606060', '#cccccc', '#eeeeee', '#e1e1e1'))
        self.setStyleSheet(f'''
            QDialog {{background:{bg}; color:{fg};}}
            QLabel {{color:{fg}; font-size:14px;}}
            QLabel#muted {{color:{muted};}}
            QLabel#status {{color:{fg}; font-size:12px; font-weight:600;}}
            QPushButton {{background:{button}; color:{fg}; border:1px solid {border};
                border-radius:10px; padding:12px 20px; font-size:14px;}}
            QPushButton:hover {{background:{hover};}}
            QPushButton:focus {{border:2px solid {fg};}}
            QPushButton#restart {{background:{fg}; color:{bg}; border-color:{fg};}}
            QPushButton#restart:hover {{background:{muted};}}
            QPushButton:disabled {{color:{muted}; background:{button};}}
        ''')
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 30, 32, 28)
        layout.setSpacing(16)
        brand = QHBoxLayout()
        logo = QLabel()
        pixmap = QPixmap(LOGO)
        if not pixmap.isNull():
            logo.setPixmap(pixmap.scaled(54, 54, Qt.AspectRatioMode.KeepAspectRatio,
                                         Qt.TransformationMode.SmoothTransformation))
            brand.addWidget(logo)
        name = QLabel('ArchiveOS')
        name.setStyleSheet('font-size:24px; font-weight:600;')
        brand.addWidget(name)
        brand.addStretch()
        layout.addLayout(brand)
        layout.addSpacing(6)
        status = QLabel(self.words[0])
        status.setObjectName('status')
        layout.addWidget(status)
        title = QLabel(self.words[1])
        title.setStyleSheet('font-size:26px; font-weight:600;')
        layout.addWidget(title)
        desc = QLabel(self.words[2])
        desc.setObjectName('muted')
        desc.setWordWrap(True)
        desc.setMaximumWidth(470)
        layout.addWidget(desc)
        self.error = QLabel()
        self.error.setWordWrap(True)
        self.error.setMaximumWidth(470)
        self.error.hide()
        layout.addWidget(self.error)
        layout.addSpacing(8)
        actions = QHBoxLayout()
        actions.addStretch()
        self.later = QPushButton(self.words[3])
        self.later.setDefault(True)
        self.later.clicked.connect(self.reject)
        self.restart = QPushButton(self.words[4])
        self.restart.setObjectName('restart')
        self.restart.setAutoDefault(False)
        self.restart.clicked.connect(self.request_restart)
        actions.addWidget(self.later)
        actions.addWidget(self.restart)
        layout.addLayout(actions)
        self.later.setFocus()

    def request_restart(self):
        if self.preview or self.process is not None:
            return
        if self.request_only:
            self.done(10)
            return
        self.error.hide()
        self.restart.setEnabled(False)
        self.restart.setText(self.words[5])
        self.process = QProcess(self)
        self.process.errorOccurred.connect(lambda _error: self.restart_failed())
        self.process.finished.connect(self.restart_finished)
        self.process.start('systemctl', ['reboot'])

    def restart_finished(self, code, status):
        if code == 0 and status == QProcess.ExitStatus.NormalExit:
            self.accept()
        else:
            self.restart_failed()

    def restart_failed(self):
        self.error.setText(self.words[6])
        self.error.show()
        self.restart.setText(self.words[4])
        self.restart.setEnabled(True)
        if self.process is not None:
            self.process.deleteLater()
            self.process = None



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lang', choices=('tr', 'en'))
    parser.add_argument('--theme', choices=('light', 'dark'))
    parser.add_argument('--preview', type=Path)
    parser.add_argument('--request-only', action='store_true')
    args = parser.parse_args()
    app = QApplication(sys.argv[:1])
    app.setApplicationName('ArchiveOS')
    dialog = RebootDialog(args.lang or system_language(),
                          args.theme or system_theme(app), bool(args.preview), args.request_only)
    if args.preview:
        dialog.show()
        def save_preview():
            app.exit(0 if dialog.grab().save(str(args.preview)) else 1)
        QTimer.singleShot(150, save_preview)
        return app.exec()
    result = dialog.exec()
    return result if args.request_only else 0


if __name__ == '__main__':
    sys.exit(main())
