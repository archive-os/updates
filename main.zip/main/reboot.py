#!/usr/bin/python3
"""Standalone ArchiveOS restart prompt. Requires python3-pyqt6.

Run as the desktop user. --preview FILE renders without permitting a reboot.
"""
import argparse
import configparser
import os
import sys
from pathlib import Path

from PyQt6.QtCore import QLocale, QProcess, QTimer, Qt
from PyQt6.QtGui import QIcon, QPalette, QPixmap
from PyQt6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel,
                             QPushButton, QVBoxLayout)

LOGO = '/usr/share/icons/Aos/aos-menu.png'
TEXT = {
    'tr': ('Güncelleme tamamlandı', 'Yeniden başlatılsın mı?',
           'Değişikliklerin uygulanması için bilgisayarınızı yeniden başlatın.',
           'Daha sonra', 'Yeniden başlat', 'Yeniden başlatılıyor…',
           'Yeniden başlatma isteği gönderilemedi. Lütfen tekrar deneyin.'),
    'en': ('Update complete', 'Restart now?',
           'Restart your computer to apply the changes.',
           'Later', 'Restart now', 'Restarting…',
           'Could not request a restart. Please try again.'),
}


def system_language():
    for key in ('LANGUAGE', 'LC_ALL', 'LC_MESSAGES', 'LANG'):
        value = os.environ.get(key, '').split(':')[0]
        if value:
            return 'tr' if value.lower().split('_')[0].split('-')[0] == 'tr' else 'en'
    return 'tr' if QLocale.system().name().startswith('tr') else 'en'


def system_theme(app):
    # Read Plasma's actual window background even when Qt uses a fallback style.
    config = configparser.ConfigParser(interpolation=None, strict=False)
    path = Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config'))) / 'kdeglobals'
    try:
        config.read(path, encoding='utf-8')
        rgb = [int(v) for v in config.get('Colors:Window', 'BackgroundNormal').split(',')[:3]]
        if len(rgb) == 3 and all(0 <= v <= 255 for v in rgb):
            return 'dark' if sum(a*b for a, b in zip(rgb, (.2126, .7152, .0722))) < 128 else 'light'
    except (OSError, ValueError, configparser.Error):
        pass
    return 'dark' if app.palette().color(QPalette.ColorRole.Window).lightness() < 128 else 'light'


class RebootDialog(QDialog):
    def __init__(self, lang, theme, preview=False):
        super().__init__()
        self.words = TEXT[lang]
        self.preview = preview
        self.process = None
        self.setWindowTitle('ArchiveOS · ' + self.words[0])
        self.setWindowIcon(QIcon(LOGO))
        self.setMinimumWidth(510)
        dark = theme == 'dark'
        bg, fg, muted, border, button, hover = (
            ('#111318', '#f5f7fa', '#a6aebb', '#343a45', '#20242c', '#2c333f') if dark else
            ('#ffffff', '#171c25', '#606b7a', '#dce1e8', '#f3f5f8', '#e6ebf2'))
        self.setStyleSheet(f'''
            QDialog {{background:{bg}; color:{fg};}}
            QLabel {{color:{fg}; font-size:14px;}}
            QLabel#muted {{color:{muted};}}
            QLabel#status {{color:#6bbced; font-size:12px; font-weight:600;}}
            QPushButton {{background:{button}; color:{fg}; border:1px solid {border};
                border-radius:10px; padding:12px 20px; font-size:14px;}}
            QPushButton:hover {{background:{hover};}}
            QPushButton:focus {{border:2px solid #69b7e5;}}
            QPushButton#restart {{background:#a9ddf7; color:#142536; border-color:#a9ddf7;}}
            QPushButton#restart:hover {{background:#c5eaff;}}
            QPushButton:disabled {{color:{muted}; background:{button};}}
        ''')
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 30, 32, 28)
        layout.setSpacing(16)
        brand = QHBoxLayout()
        logo = QLabel()
        pixmap = QPixmap(LOGO)
        if not pixmap.isNull():
            logo.setPixmap(pixmap.scaled(54, 54, Qt.AspectRatioMode.KeepAspectRatio,
                                         Qt.TransformationMode.SmoothTransformation))
            brand.addWidget(logo)
        name = QLabel('ArchiveOS')
        name.setStyleSheet('font-size:24px; font-weight:600;')
        brand.addWidget(name)
        brand.addStretch()
        layout.addLayout(brand)
        layout.addSpacing(6)
        status = QLabel(self.words[0])
        status.setObjectName('status')
        layout.addWidget(status)
        title = QLabel(self.words[1])
        title.setStyleSheet('font-size:26px; font-weight:600;')
        layout.addWidget(title)
        desc = QLabel(self.words[2])
        desc.setObjectName('muted')
        desc.setWordWrap(True)
        desc.setMaximumWidth(470)
        layout.addWidget(desc)
        self.error = QLabel()
        self.error.setWordWrap(True)
        self.error.setMaximumWidth(470)
        self.error.hide()
        layout.addWidget(self.error)
        layout.addSpacing(8)
        actions = QHBoxLayout()
        actions.addStretch()
        self.later = QPushButton(self.words[3])
        self.later.setDefault(True)
        self.later.clicked.connect(self.reject)
        self.restart = QPushButton(self.words[4])
        self.restart.setObjectName('restart')
        self.restart.setAutoDefault(False)
        self.restart.clicked.connect(self.request_restart)
        actions.addWidget(self.later)
        actions.addWidget(self.restart)
        layout.addLayout(actions)
        self.later.setFocus()

    def request_restart(self):
        if self.preview or self.process is not None:
            return
        self.error.hide()
        self.restart.setEnabled(False)
        self.restart.setText(self.words[5])
        self.process = QProcess(self)
        self.process.errorOccurred.connect(lambda _error: self.restart_failed())
        self.process.finished.connect(self.restart_finished)
        # logind/polkit handles the desktop user's authorization; no force or sudo.
        self.process.start('systemctl', ['reboot'])

    def restart_finished(self, code, status):
        if code == 0 and status == QProcess.ExitStatus.NormalExit:
            self.accept()
        else:
            self.restart_failed()

    def restart_failed(self):
        self.error.setText(self.words[6])
        self.error.show()
        self.restart.setText(self.words[4])
        self.restart.setEnabled(True)
        if self.process is not None:
            self.process.deleteLater()
            self.process = None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lang', choices=('tr', 'en'))
    parser.add_argument('--theme', choices=('light', 'dark'))
    parser.add_argument('--preview', type=Path)
    args = parser.parse_args()
    app = QApplication(sys.argv[:1])
    app.setApplicationName('ArchiveOS')
    dialog = RebootDialog(args.lang or system_language(),
                          args.theme or system_theme(app), bool(args.preview))
    if args.preview:
        dialog.show()
        def save_preview():
            app.exit(0 if dialog.grab().save(str(args.preview)) else 1)
        QTimer.singleShot(150, save_preview)
        return app.exec()
    dialog.exec()
    return 0


if __name__ == '__main__':
    sys.exit(main())
