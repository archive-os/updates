# Terminal menu hotfix · 18 October 2026

Desktop/main 2.0.2 now includes aos-terminal 2.1.7, preserving the delivered 2.1.6 UI and translations. Backup: /tmp/main-before-terminal-menu-20261018.

Folder and script service menus now have names and icons in both their main entry and action groups. Icon=aos-terminal resolves through hicolor, with the existing compatibility icon retained. System service menus have executable permissions, matching the existing per-user copies. The main updater sets dolphinrc [ContextMenu] ShowOpenTerminal=false for existing users and /etc/skel; this removes Dolphin's duplicate built-in terminal action. Existing unrelated Dolphin preferences are preserved. Legacy Konsole service-menu masks remain in place.

Verification: 63 delivered updater tests passed, including duplicate-action suppression, preserving other preferences and repeated application. All 31 terminal tests passed against the extracted 2.1.7 DEB. Qt rendered both main/action icons under hicolor, breeze and breeze-dark with standard icon search paths. System service-menu executable permissions were checked. The extracted source archive includes Turkish translations.

No host installation was performed. Physical Dolphin/Wayland interaction and a complete installed-system upgrade remain unverified.

Sources: [Dolphin setting schema](https://github.com/KDE/dolphin/blob/master/src/settings/dolphin_contextmenusettings.kcfg), [context-menu gate](https://github.com/KDE/dolphin/blob/master/src/dolphincontextmenu.cpp), [KDE service menus](https://develop.kde.org/docs/apps/dolphin/service-menus/).
