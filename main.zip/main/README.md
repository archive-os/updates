# ArchiveOS update bundle

Run `./install.sh --dry-run` to verify the bundle and see the plan.
Run `./install.sh` in a terminal on the installed ArchiveOS system to update it.
Use `--lang tr` or `--lang en` to select the language explicitly.

Order: preflight and integrity checks → mandatory Timeshift snapshot → Ubuntu
sources copied from the ISO → apt update/upgrade → simulated/guarded dependency
transition (dist-upgrade) → apt clean → ArchiveOS branding/themes/KDE defaults
and complete replacement of wallpapers/ArchiveOS → Ubuntu/Kubuntu branding cleanup
and Plymouth selection → nine local application DEBs → services/ installation
and enablement → initramfs and GRUB rebuild → standalone reboot.py.

Timeshift must already be installed and configured. Snapshot creation uses the
default on-demand tag (no explicit --tags O, for older Timeshift compatibility)
and a stable C locale. Per-file console output is disabled with --quiet. A Btrfs root mounted at /@ uses native snapshots when the configured backup UUID matches the root filesystem; external backup destinations and other layouts retain their configured mode. Snapshot IDs are verified after creation. A failed snapshot stops all
changes. The script refuses live/overlay systems, chroots, non-Ubuntu systems
and a broken dpkg state. The target Ubuntu release may differ: Questing systems
use the ISO Resolute sources as explicitly requested. After the verified Timeshift snapshot, all old APT source files
(including third-party repositories) are removed and replaced by the ISO set.
No additional repository/keyring file backup is made.
This is a repository-based distribution transition, not do-release-upgrade.
The dependency transition is simulated before execution and stops if it would
remove required desktop/boot/backup packages. Replaced library packages may be
removed. apt clean clears downloaded package archives, not installed programs.
No autoremove is run. This is not an ISO builder.
Obsolete versioned kernel image, module and header packages are explicitly purged
after a checked APT simulation. The newest kernel per flavor and the running kernel
are retained; a replacement must have both vmlinuz and initrd. Generic/HWE tracking
metapackages are retained. The boot worker removes the previous running kernel after
booting its replacement. An APT post-invoke hook schedules the same worker after
future package transactions, outside the dpkg lock. No unrelated removal is allowed
by the simulation. GRUB is updated after removal. The restart dialog loads
`/usr/share/icons/Aos/aos-menu.png` for its logo and window icon.
After application installation, only `org.mozilla.firefox` Flatpak app refs are
uninstalled from the system and existing users' standard Flatpak installations.
User installations are managed as their owner. Native/Snap Firefox, other Flatpak
apps/runtimes and Firefox profile data are retained; `--delete-data` is not used.
Standalone legacy `fastfetch` calls in system/skel/user Bash rc files are routed to
one shared hook. A Bash process marker prevents duplicate output when multiple rc
files source it. Each new interactive Bash process still shows fastfetch once;
noninteractive Bash does not. Other shell customizations and explicit calls with
custom arguments are retained.
The original animation stays in the existing ArchiveOS White package; Dark uses
that same animation. No third global theme or borrowed KDE screenshot is added.
The previously generated org.archiveos.splash.desktop package is removed.
SDDM keyboard dependencies are installed. X11 uses Qt Virtual Keyboard; KWin
Wayland greeters start Maliit through --inputmethod, preserving compositor options.

The overlay comes from `/home/hakki/aos-make/aos-squash-data/extracted`.
`manifest.json` records source paths and checksums. Accounts, passwords, hostnames,
network settings, fstab, machine-id, SSH keys and Timeshift device settings are
excluded. Existing `programs/` contains the application DEBs.

Existing user panel and theme settings are preserved. No global theme is
reapplied at the next KDE login.
Personal documents are preserved. Choosing Later or closing the dialog never
reboots. On systems without a GUI, the same question appears in the terminal;
Enter means Later. The update keeps SDDM and KWin running; plasmashell is restored after the restart choice.

Updated files and removed vendor branding are saved under
`/var/backups/archiveos-update/<timestamp>/`; execution logs are in
`/var/log/archiveos-update/`. On failure, there is no automatic reboot; inspect
the log and use the recorded Timeshift snapshot to restore if needed.

Ubuntu/Kubuntu Plymouth theme directories are removed after selecting ArchiveOS.
After APT, theme directories are scanned recursively for names containing `ubuntu`
(case insensitive, including Kubuntu): Plasma, SDDM, Plymouth, wallpapers/backgrounds,
color schemes, GTK/Aurorae and Konsole themes. Named icon-theme packages are also
removed. System, local system, existing users and skeleton assets are covered;
directory symlinks are never followed. Kubuntu Website and Restore desktop links
launchers, plus Howto Guides (`org.kfocus.web.howtos.desktop`) and Manage Software
(`org.kubuntu.manage-software.desktop`), are removed from
system/user applications, desktop folders and autostart.
Removed assets retain the existing `/var/backups/archiveos-update` backup behavior.
Plymouth `details`, `text`, `tribar`, `breeze`, `breeze-text`, `bgrt` and `spinner`
theme directories are removed. The original ArchiveOS animation remains;
`ArchiveOS-Text` uses the existing details plugin for a text fallback. The Ubuntu
initramfs hook's unconditional details/text directory copies become optional before
cleanup, avoiding missing-directory errors. Plugin binaries are retained.
Preflight checks the required `details.so` plugin, not the intentionally removed
vendor `details/details.plymouth` theme, so the update can be run again after cleanup.
A future Plymouth package reinstall may restore vendor assets/the hook; rerun this update
to apply cleanup again.
Ubuntu-named logo compatibility files required by the upstream initramfs hook
contain ArchiveOS artwork. The system initramfs is rebuilt, so the obsolete
Ubuntu artwork is not retained in the newly generated boot image.

CLI references: [Timeshift](https://manpages.ubuntu.com/manpages/noble/man1/timeshift.1.html),
[APT](https://manpages.ubuntu.com/manpages/jammy/man8/apt-get.8.html).

Terminal output streams live, including captured diagnostic commands and each
overlay file/directory/link, backup and removal. A stage progress bar shows the
current phase; overlay progress uses completed archive entries. Percentages are
phase milestones, not elapsed-time or APT download estimates. A working indicator
continues while external commands are quiet (plain status lines when redirected).
Command output and file operations are also recorded in the execution log.

The bundled reboot.py runs as the desktop user only after all stages succeed.
The services/ user unit is copied to /etc/systemd/user and its autostart launcher
to /etc/xdg/autostart after application installation. Existing panel layout and theme selection are preserved.

Calamares settings (`/etc/calamares`, system/skel/user `calamaresrc`) are removed
after the snapshot and ISO overlay; the exported KDE defaults exclude calamaresrc.
The custom ISO ArchiveOS Plymouth theme, including spinner.png and its script,
is copied unchanged and selected before rebuilding initramfs. The generic vendor
`spinner` theme is distinct from ArchiveOS/spinner.png.

The custom KDE login animation is also exported unchanged from
org.archiveos.desktop/contents/splash (Splash.qml, Aos artwork and busy widget).
White owns this animation; Dark refers to White, without adding another theme.
Export fails if the KDE animation or Plymouth spinner assets are missing.

Local ArchiveOS White/Dark package overrides are backed up and removed in full.
A local package without splash shadows the system package and hides its animation.

The existing canonical splash package is displayed as ArchiveOS in all locales.
Its package ID, animation and appearance settings are retained; the White package
uses the same metadata name in the global theme list as required by KDE.

Calamares launchers (calamares.desktop, calamares-launch-oem.desktop and
kubuntu-calamares.desktop) are removed with the existing backup mechanism.

## 18 October 2026 appearance refresh

Eight existing application payloads receive blue system-aware appearance fixes. Welcome artwork is unchanged. Gaming Center 1.2.3 and ArchiveOS Terminal 2.1.3 are in programs/ and included in the installer list. Duplicate unpacked etc/usr trees and duplicate root application DEBs were removed. Unused CalaTheme, Juk and Discover notification defaults were omitted. KDE White/Dark share the original ArchiveOS splash; disabled defaults and the nested KConfig group are repaired. GRUB uses the ArchiveOS Dark wallpaper. Physical boot/login and real package operations still require target-machine validation.

## 18 October 2026 fixes

The original ArchiveOS logo is restored in aosver. Terminal tabs are compact; tab menu actions follow their session when tabs move or close. The restart dialog follows the current KDE light/dark selection with a white/black palette (--theme can override it), a clean desktop environment and session discovery for sudo/pkexec. The dialog returns the restart choice to the updater, which performs the restart. If the dialog fails, the updater offers a terminal prompt without marking the completed update as failed. Root DEBs have been consolidated into programs/ using their newest versions. Application names are unchanged. Reboot, login and a complete system update require target-machine verification.

Existing users keep their kdeglobals, plasmarc and kdedefaults settings. Existing system appearance defaults are retained for users who inherit their theme. The next-login helper no longer reapplies the white global theme or resets the desktop layout. New users still receive the shipped skeleton defaults. KSplash repairs remain enabled.
## Update display

A full-screen black ArchiveOS display shows a localized Turkish/English heading, phase progress and a bottom terminal toggle for live read-only logs. The GUI runs as the desktop user from a temporary read-only payload; the privileged updater owns the status file and update commands. Only plasmashell is stopped after the display is ready; KWin and the graphical session remain running. The display hides before the restart question. Choosing Later or closing that question restores plasmashell and closes the update display. Errors and an unexpected display exit also restore plasmashell. Actual desktop service/Wayland behavior and a full system upgrade still need target-machine validation.
ArchiveOS Terminal 2.1.2: white/dark terminal surface, larger tab row, folder context-menu integration and Go to folder. The full-screen update interface uses a black background.

## 2.0.2 fixes

System identity and KDE About report 2.0.2. Identity is verified and reapplied after package installation. ArchiveOS Terminal 2.1.3 recognizes White system themes with per-file KDE priority, has a slightly taller tab row, and detaches a dragged tab into a separate window while preserving its shell and running commands. The update display adapts to small screens, follows replaced logs, and hides before the restart question so the dialog remains visible. The update replaces the Konsole application with ArchiveOS Terminal, preserves the separate konsole-kpart engine, sets KDE and x-terminal-emulator defaults, and assigns Ctrl+Alt+T without changing other shortcuts. Percentages indicate stages, not elapsed time. Physical Wayland/X11, a complete APT transition and reboot still require target-system testing.

ArchiveOS Terminal 2.1.4: local .sh files gain Run with ArchiveOS Terminal in Dolphin (ArchiveOS Terminalle çalıştır in Turkish). Non-executable files first ask whether to enable execution; only Yes adds the owner execute bit and runs the script. No cancels. Scripts run from their own folder and output stays until Enter. 17 terminal tests passed, including permission refusal/approval/failure and a real PTY filename/working-directory/output check. Physical Dolphin interaction remains untested. Updated release sources are included in the terminal DEB at /usr/share/doc/aos-terminal/source.tar.gz.

## Runtime fixes and Plasma update checker

The first Timeshift list may return 1 with a confirmed empty repository. That initial state now proceeds to snapshot creation; other list failures, failed creation, and absent new snapshot IDs still stop all update operations. A successful post-create list and new snapshot remain mandatory.
At update-screen startup a temporary KWin script minimizes other normal windows while retaining the update window. The display stays above other windows and ignores Alt+F4 and window-close requests until the updater closes it. The restart prompt remains usable. Preview mode does not minimize windows. This uses the KWin scripting API: https://develop.kde.org/docs/plasma/kwin/api/ . The script is unloaded after execution; the updater now additionally installs a rule scoped to its own window, forces full-screen geometry and blocks global shortcuts while updating. Runtime shortcut blocking is released on exit, error or a lost updater process. Other user window rules are preserved.
ArchiveOS Terminal 2.1.5 removes the bottom-right shell/UTF-8/font-size labels. Follow system remains the default; explicit theme choices remain available. The .sh context menu and executable-permission confirmation remain included.
The service display name is ArchiveOS Update checker. Its user unit is ordered after the D-Bus-ready plasma-plasmashell.service and enabled under plasma-workspace.target. XDG startup is KDE-only. The Update Manager 2.2.0+blue2 schedule performs a one-time migration to weekly checks; subsequent explicit choices remain available. Successful checks remain seven days apart, across logins, and failed requests retain their retry backoff. Global reenable removes old target links during the main update.
Validation: 40 updater tests plus the service activation test; 8 screen tests including Alt+F4/backend close and KWin JavaScript evaluation; 18 terminal Qt/PTY tests; weekly migration/seven-day timing checks; systemd unit and autostart validation. A fresh isolated D-Bus notification test could not start because this sandbox refuses D-Bus socket creation. Physical KWin/Dolphin/session login and a complete upgrade remain untested. The host was not updated.


## 2.0.2 interface and reliability revision

ArchiveOS Terminal 2.1.6 opens at 960×540 (16:9), with wider rounded tabs, inset close buttons and a larger vector search icon. Switching sessions crossfades when animations are enabled. A drag preview indicates when releasing will move the running session to a new window. Konsole's Turkish search catalog is included; native search controls, option menus and tooltips follow the selected Turkish/English UI.

Dolphin's legacy Konsole run/open actions are hidden using local service-menu overrides; ArchiveOS Terminal actions remain available. The update finalizes both os-release files, LSB/KDE identity and the JSON version records used by ArchiveOS applications, preserving unrelated JSON fields. The result is ArchiveOS 2.0.2.

The wallpaper autostart entry is named ArchiveOS Theme Wallpaper Service and uses a new matching blue wallpaper icon. The restart dialog follows the user's light/dark scheme and uses black/white controls. Physical KWin/Dolphin/Wayland behavior, snapshot timing and a full distribution update still require an installed-system test. See VALIDATION-2.0.2.md for this revision.

Fastfetch now displays `ArchiveOS v2.0.2 (resolute)` in the system configuration and the configuration copied to existing users. Bundle verification rejects a Fastfetch version that differs from the manifest. The TR/EN update screen explains that the system may appear frozen, warns against turning it off and points to the Timeshift snapshot for recovery after an error. The warning also fits a 640×480 screen with the terminal log open.

## Terminal menu correction

ArchiveOS Terminal 2.1.7 supplies named menu icons and complete folder/script service-menu metadata. The update disables Dolphin's duplicate built-in Open Terminal context action while retaining ArchiveOS actions. See VALIDATION-terminal-menu.md.
