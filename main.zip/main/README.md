# ArchiveOS update bundle

Run `./install.sh --dry-run` to verify the bundle and see the plan.
Run `./install.sh` in a terminal on the installed ArchiveOS system to update it.
Use `--lang tr` or `--lang en` to select the language explicitly.

Order: preflight and integrity checks → mandatory Timeshift snapshot → Ubuntu
sources copied from the ISO → apt update/upgrade → simulated/guarded dependency
transition (dist-upgrade) → apt clean → ArchiveOS branding/themes/KDE defaults
and complete replacement of wallpapers/ArchiveOS → Ubuntu/Kubuntu branding cleanup
and Plymouth selection → eight local application DEBs → services/ installation
and enablement → initramfs and GRUB rebuild → standalone reboot.py.

Timeshift must already be installed and configured. Snapshot creation uses the
default on-demand tag (no explicit --tags O, for older Timeshift compatibility)
and a stable C locale. A failed snapshot stops all
changes. The script refuses live/overlay systems, chroots, non-Ubuntu systems
and a broken dpkg state. The target Ubuntu release may differ: Questing systems
use the ISO Resolute sources as explicitly requested. After the verified Timeshift snapshot, all old APT source files
(including third-party repositories) are removed and replaced by the ISO set.
No additional repository/keyring file backup is made.
This is a repository-based distribution transition, not do-release-upgrade.
The dependency transition is simulated before execution and stops if it would
remove required desktop/boot/backup packages. Replaced library packages may be
removed. apt clean clears downloaded package archives, not installed programs.
No autoremove is run. This is not an ISO builder.
Obsolete versioned kernel image, module and header packages are explicitly purged
after a checked APT simulation. The newest kernel per flavor and the running kernel
are retained; a replacement must have both vmlinuz and initrd. Generic/HWE tracking
metapackages are retained. The boot worker removes the previous running kernel after
booting its replacement. An APT post-invoke hook schedules the same worker after
future package transactions, outside the dpkg lock. No unrelated removal is allowed
by the simulation. GRUB is updated after removal. The restart dialog loads
`/usr/share/icons/Aos/aos-menu.png` for its logo and window icon.
After application installation, only `org.mozilla.firefox` Flatpak app refs are
uninstalled from the system and existing users' standard Flatpak installations.
User installations are managed as their owner. Native/Snap Firefox, other Flatpak
apps/runtimes and Firefox profile data are retained; `--delete-data` is not used.
Standalone legacy `fastfetch` calls in system/skel/user Bash rc files are routed to
one shared hook. A Bash process marker prevents duplicate output when multiple rc
files source it. Each new interactive Bash process still shows fastfetch once;
noninteractive Bash does not. Other shell customizations and explicit calls with
custom arguments are retained.
The original animation stays in the existing ArchiveOS White package; Dark uses
that same animation. No third global theme or borrowed KDE screenshot is added.
The previously generated org.archiveos.splash.desktop package is removed.
SDDM keyboard dependencies are installed. X11 uses Qt Virtual Keyboard; KWin
Wayland greeters start Maliit through --inputmethod, preserving compositor options.

The overlay comes from `/home/hakki/aos-make/aos-squash-data/extracted`.
`manifest.json` records source paths and checksums. Accounts, passwords, hostnames,
network settings, fstab, machine-id, SSH keys and Timeshift device settings are
excluded. Existing `programs/` contains the application DEBs.

Existing user panel/theme settings are backed up. The ArchiveOS White global
theme and shipped ArchiveOS panel are applied once at the next KDE login.
Personal documents are preserved. Choosing Later or closing the dialog never
reboots. On systems without a GUI, the same question appears in the terminal;
Enter means Later. The update never restarts SDDM or Plasma mid-session.

Updated files and removed vendor branding are saved under
`/var/backups/archiveos-update/<timestamp>/`; execution logs are in
`/var/log/archiveos-update/`. On failure, there is no automatic reboot; inspect
the log and use the recorded Timeshift snapshot to restore if needed.

Ubuntu/Kubuntu Plymouth theme directories are removed after selecting ArchiveOS.
After APT, theme directories are scanned recursively for names containing `ubuntu`
(case insensitive, including Kubuntu): Plasma, SDDM, Plymouth, wallpapers/backgrounds,
color schemes, GTK/Aurorae and Konsole themes. Named icon-theme packages are also
removed. System, local system, existing users and skeleton assets are covered;
directory symlinks are never followed. Kubuntu Website and Restore desktop links
launchers, plus Howto Guides (`org.kfocus.web.howtos.desktop`) and Manage Software
(`org.kubuntu.manage-software.desktop`), are removed from
system/user applications, desktop folders and autostart.
Removed assets retain the existing `/var/backups/archiveos-update` backup behavior.
Plymouth `details`, `text`, `tribar`, `breeze`, `breeze-text`, `bgrt` and `spinner`
theme directories are removed. The original ArchiveOS animation remains;
`ArchiveOS-Text` uses the existing details plugin for a text fallback. The Ubuntu
initramfs hook's unconditional details/text directory copies become optional before
cleanup, avoiding missing-directory errors. Plugin binaries are retained.
Preflight checks the required `details.so` plugin, not the intentionally removed
vendor `details/details.plymouth` theme, so the update can be run again after cleanup.
A future Plymouth package reinstall may restore vendor assets/the hook; rerun this update
to apply cleanup again.
Ubuntu-named logo compatibility files required by the upstream initramfs hook
contain ArchiveOS artwork. The system initramfs is rebuilt, so the obsolete
Ubuntu artwork is not retained in the newly generated boot image.

CLI references: [Timeshift](https://manpages.ubuntu.com/manpages/noble/man1/timeshift.1.html),
[APT](https://manpages.ubuntu.com/manpages/jammy/man8/apt-get.8.html).

Terminal output streams live, including captured diagnostic commands and each
overlay file/directory/link, backup and removal. A stage progress bar shows the
current phase; overlay progress uses completed archive entries. Percentages are
phase milestones, not elapsed-time or APT download estimates. A working indicator
continues while external commands are quiet (plain status lines when redirected).
Command output and file operations are also recorded in the execution log.

The bundled reboot.py runs as the desktop user only after all stages succeed.
The services/ user unit is copied to /etc/systemd/user and its autostart launcher
to /etc/xdg/autostart after application installation. Panel layout is replaced
with the ISO ArchiveOS layout once at the next KDE login.

Calamares settings (`/etc/calamares`, system/skel/user `calamaresrc`) are removed
after the snapshot and ISO overlay; the exported KDE defaults exclude calamaresrc.
The custom ISO ArchiveOS Plymouth theme, including spinner.png and its script,
is copied unchanged and selected before rebuilding initramfs. The generic vendor
`spinner` theme is distinct from ArchiveOS/spinner.png.

The custom KDE login animation is also exported unchanged from
org.archiveos.desktop/contents/splash (Splash.qml, Aos artwork and busy widget).
White owns this animation; Dark refers to White, without adding another theme.
Export fails if the KDE animation or Plymouth spinner assets are missing.

Local ArchiveOS White/Dark package overrides are backed up and removed in full.
A local package without splash shadows the system package and hides its animation.

The existing canonical splash package is displayed as ArchiveOS in all locales.
Its package ID, animation and appearance settings are retained; the White package
uses the same metadata name in the global theme list as required by KDE.

Calamares launchers (calamares.desktop, calamares-launch-oem.desktop and
kubuntu-calamares.desktop) are removed with the existing backup mechanism.
