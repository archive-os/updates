import importlib.util, io, json, os, subprocess, tarfile, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
SPEC=importlib.util.spec_from_file_location('aos_update',Path(__file__).parents[1]/'helpers/update.py');u=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(u)
class FakeRunner:
    def __init__(self,fail=None):self.commands=[];self.fail=fail;self.created=False
    def __call__(self,args,capture=False,check=True,env=None):
        self.commands.append(args)
        if self.fail and self.fail in args:raise RuntimeError('simulated failure')
        out=''
        if args[:2]==['timeshift','--create']:self.created=True
        if args[:2]==['timeshift','--list']:out='2026-10-08_03-00-00 O ArchiveOS' if self.created else ''
        if args[:2]==['bash','-c']:out='rootflags=subvol=@ nosplash\nquiet plymouth.enable=0 mitigations=off\n'
        if '--query' in args:out='Alternative: /usr/share/plymouth/themes/ubuntu-logo/ubuntu-logo.plymouth\n'
        if '--query' in args:
            out+=''.join('Alternative: /usr/share/plymouth/themes/'+n+'/'+n+'.plymouth\n' for n in u.PLYMOUTH_REMOVE)
        return subprocess.CompletedProcess(args,0,out)
class UpdateTests(unittest.TestCase):
    def test_existing_dark_light_and_custom_theme_configs_survive_overlay(self):
        for selection in ('ArchiveOSDark','ArchiveOSWhite','MyCustomTheme'):
            with self.subTest(selection=selection),tempfile.TemporaryDirectory() as temp:
                engine=self.engine(temp,FakeRunner())
                user=type('User',(),{'pw_uid':1000,'pw_gid':1000,'pw_dir':'/home/test'})()
                paths=('home/test/.config/kdeglobals','home/test/.config/kdedefaults/kdeglobals','home/test/.config/plasmarc','etc/xdg/kdeglobals','etc/xdg/plasmarc','usr/share/archiveos-default-settings/kdeglobals')
                expected={}
                for rel in paths:
                    path=engine.root/rel;path.parent.mkdir(parents=True,exist_ok=True)
                    expected[rel]=('[General]\nColorScheme='+selection+'\n[KDE]\nLookAndFeelPackage='+selection+'\n[Custom]\nValue=keep\n').encode()
                    path.write_bytes(expected[rel])
                engine.detail=lambda *args:None
                with patch.object(u.pwd,'getpwall',return_value=[user]),patch.object(u.os,'chown'):
                    engine.overlay()
                for rel,data in expected.items():self.assertEqual((engine.root/rel).read_bytes(),data)
                for rel in ('etc/fastfetch/config.jsonc','home/test/.config/fastfetch/config.jsonc'):
                    config=json.loads((engine.root/rel).read_text())
                    module=next(m for m in config['modules'] if isinstance(m,dict) and m.get('type')=='os')
                    self.assertEqual(module['format'],'ArchiveOS v'+engine.m['version']+' ('+engine.m['ubuntu_codename']+')')

    def test_verify_rejects_stale_fastfetch_version(self):
        bundle=Path(os.environ.get('ARCHIVEOS_TEST_BUNDLE',Path(__file__).parents[1]))
        manifest=json.loads((bundle/'manifest.json').read_text())
        manifest.update(files={},packages=[],services=[])
        with tarfile.open(bundle/'archiveos-overlay.tar.gz') as archive:
            payload={rel:archive.extractfile(rel).read() for rel in ('etc/os-release','usr/lib/os-release','etc/fastfetch/config.jsonc')}
        for stale in (False,True):
            with self.subTest(stale=stale),tempfile.TemporaryDirectory() as temp:
                with tarfile.open(Path(temp)/'archiveos-overlay.tar.gz','w:gz') as archive:
                    for rel,data in payload.items():
                        if stale and rel=='etc/fastfetch/config.jsonc':data=data.replace(b'v2.0.2',b'v2.0.1')
                        member=tarfile.TarInfo(rel);member.size=len(data);archive.addfile(member,io.BytesIO(data))
                if stale:
                    with self.assertRaisesRegex(ValueError,'Fastfetch version'):u.verify(Path(temp),manifest)
                else:u.verify(Path(temp),manifest)

    def test_calamares_settings_removed_and_custom_spinner_preserved(self):
        with tempfile.TemporaryDirectory() as temp:
            engine=self.engine(temp,FakeRunner())
            settings=('etc/calamares/settings.conf','etc/xdg/calamaresrc','etc/skel/.config/calamaresrc','root/.config/calamaresrc','usr/share/archiveos-default-settings/calamaresrc')
            for rel in settings:
                p=engine.root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('legacy')
            spinner=engine.root/'usr/share/plymouth/themes/ArchiveOS/spinner.png'
            spinner.parent.mkdir(parents=True,exist_ok=True);spinner.write_bytes(b'custom spinner')
            with patch.object(u.pwd,'getpwall',return_value=[]):
                engine.cleanup_branding();engine.cleanup_branding()
            for rel in settings:
                self.assertFalse((engine.root/rel).exists())
                self.assertEqual((engine.backup/'files'/rel).read_text(),'legacy')
            self.assertEqual(spinner.read_bytes(),b'custom spinner')

    def test_requested_stage_order_and_service_failure_stops_boot(self):
        with tempfile.TemporaryDirectory() as temp:
            engine=self.engine(temp,FakeRunner());events=[]
            for name in ('snapshot','repos','upgrade','overlay','apps','services','finalize_identity','boot'):
                setattr(engine,name,lambda name=name:events.append(name))
            engine.execute()
            self.assertEqual(events,['snapshot','repos','upgrade','overlay','apps','services','finalize_identity','boot'])
            events.clear()
            def failed_services():
                events.append('services')
                raise RuntimeError('service installation failed')
            engine.services=failed_services
            with self.assertRaises(RuntimeError):engine.execute()
            self.assertNotIn('boot',events)

    def test_iso_wallpaper_replaces_old_directory_and_services_use_payload(self):
        with tempfile.TemporaryDirectory() as temp:
            engine=self.engine(temp,FakeRunner())
            wallpaper=engine.root/'usr/share/wallpapers/ArchiveOS';wallpaper.mkdir(parents=True)
            (wallpaper/'stale.png').write_bytes(b'old')
            with patch.object(u.pwd,'getpwall',return_value=[]):engine.overlay()
            self.assertFalse((wallpaper/'stale.png').exists())
            self.assertTrue((engine.backup/'files/usr/share/wallpapers/ArchiveOS/stale.png').exists())
            engine.services()
            for item in engine.m['services']:
                self.assertEqual((engine.root/item['target']).read_bytes(),(engine.bundle/item['file']).read_bytes())
    def test_disabled_splash_is_enabled_without_losing_other_groups(self):
        text='[Other]\nTheme=custom\n[KSplash]\nEngine=none\nTheme=none\n[Keep]\nValue=1\n'
        fixed=u.set_splash_config(text)
        self.assertIn('[Other]\nTheme=custom',fixed)
        self.assertIn('[KSplash]\nTheme=org.archiveos.desktop\nEngine=KSplashQML',fixed)
        self.assertIn('[Keep]\nValue=1',fixed)
        self.assertEqual(fixed,u.set_splash_config(fixed))

    def test_splash_consolidation_keeps_white_dark_and_original_animation(self):
        with tempfile.TemporaryDirectory() as temp:
            engine=self.engine(temp,FakeRunner());themes=('org.archiveos.desktop','org.archiveos-dark.desktop')
            for base in ('usr/share','home/test/.local/share'):
                for theme in themes:
                    folder=engine.root/base/'plasma/look-and-feel'/theme
                    (folder/'contents/splash/images').mkdir(parents=True)
                    (folder/'contents/splash/Splash.qml').write_text('original animation')
                    (folder/'contents/splash/images/aos.png').write_bytes(b'original logo')
                    (folder/'metadata.json').write_text(theme)
                    (folder/'contents/defaults').write_text('[kdeglobals][General]\nColorScheme=WhiteOrDark\n[KSplash]\nTheme='+theme+'\n[Other]\nKeep=yes\n')
            cfg=engine.root/'home/test/.config/kdedefaults/ksplashrc';cfg.parent.mkdir(parents=True);cfg.write_text('[KSplash]\nTheme=org.archiveos-dark.desktop\nEngine=KSplashQML\n')
            user=type('User',(),{'pw_uid':1000,'pw_dir':'/home/test'})()
            with patch.object(u.pwd,'getpwall',return_value=[user]):engine.consolidate_splash();engine.consolidate_splash()
            shared=engine.root/'usr/share/plasma/look-and-feel'/u.SPLASH_ID
            self.assertEqual((shared/'contents/splash/Splash.qml').read_text(),'original animation')
            self.assertEqual((shared/'contents/splash/images/aos.png').read_bytes(),b'original logo')
            self.assertEqual((shared/'metadata.json').read_text(),'org.archiveos.desktop')
            self.assertFalse((shared/'contents/previews/splash.png').exists())
            self.assertFalse((shared.parent/u.LEGACY_SPLASH_ID).exists())
            for base in ('usr/share','home/test/.local/share'):
                for theme in themes:
                    folder=engine.root/base/'plasma/look-and-feel'/theme
                    if base!='usr/share':
                        self.assertFalse(folder.exists())
                        self.assertTrue((engine.backup/'files'/base/'plasma/look-and-feel'/theme/'metadata.json').exists())
                        continue
                    self.assertEqual((folder/'contents/splash').exists(),theme==u.SPLASH_ID)
                    self.assertEqual((folder/'metadata.json').read_text(),theme)
                    self.assertIn('ColorScheme=WhiteOrDark', (folder/'contents/defaults').read_text())
                    self.assertIn('[ksplashrc][KSplash]',(folder/'contents/defaults').read_text())
                    self.assertIn('Theme='+u.SPLASH_ID+'\n[Other]',(folder/'contents/defaults').read_text())
            self.assertIn('Theme='+u.SPLASH_ID+'\nEngine=',cfg.read_text())
    def test_sddm_wayland_keyboard_keeps_compositor_options(self):
        with tempfile.TemporaryDirectory() as temp:
            engine=self.engine(temp,FakeRunner())
            conf=engine.root/'etc/sddm.conf.d/10-wayland.conf';conf.parent.mkdir(parents=True)
            conf.write_text('[General]\nDisplayServer=wayland\n[Wayland]\nCompositorCommand=kwin_wayland --drm --no-lockscreen --locale1\n')
            engine.repair_sddm_keyboard();engine.repair_sddm_keyboard()
            fixed=(conf.parent/'zzzz-archiveos-keyboard.conf').read_text()
            self.assertIn('--drm --no-lockscreen --locale1 --inputmethod /usr/bin/maliit-keyboard',fixed)
            self.assertEqual(fixed.count('--inputmethod'),1)
    def test_warp_tray_follows_plasma_exit_without_changing_daemon(self):
        with tempfile.TemporaryDirectory() as temp:
            engine=self.engine(temp,FakeRunner());engine.repair_session_exit()
            drop=engine.root/'etc/systemd/user/warp-taskbar.service.d/50-archiveos-session.conf'
            self.assertFalse(drop.exists())
            tray=engine.root/'usr/lib/systemd/user/warp-taskbar.service';tray.parent.mkdir(parents=True)
            tray.write_text('[Unit]\nBindsTo=graphical-session.target\n')
            engine.repair_session_exit();engine.repair_session_exit()
            self.assertIn('PartOf=graphical-session.target plasma-workspace.target',drop.read_text())
            self.assertEqual(tray.read_text(),'[Unit]\nBindsTo=graphical-session.target\n')
    def test_sddm_x11_keyboard(self):
        with tempfile.TemporaryDirectory() as temp:
            engine=self.engine(temp,FakeRunner());engine.repair_sddm_keyboard()
            fixed=(engine.root/'etc/sddm.conf.d/zzzz-archiveos-keyboard.conf').read_text()
            self.assertIn('InputMethod=qtvirtualkeyboard',fixed)
            self.assertNotIn('CompositorCommand',fixed)
    def test_fastfetch_normalization_preserves_customization_and_is_repeatable(self):
        text='alias ll="ls -l"\nfastfetch\n# ArchiveOS interactive shell branding\n'+u.FASTFETCH_SOURCE+'\n'
        fixed=u.normalize_fastfetch(text,system=True)
        self.assertEqual(fixed.count(u.FASTFETCH_SOURCE),1)
        self.assertIn('alias ll="ls -l"',fixed)
        self.assertEqual(u.normalize_fastfetch(fixed,system=True),fixed)
        user=u.normalize_fastfetch('export EDITOR=vim\nfastfetch\nfastfetch --logo custom\n')
        self.assertIn('fastfetch --logo custom',user);self.assertIn('export EDITOR=vim',user)
        self.assertEqual(u.normalize_fastfetch(user),user)
    def test_fastfetch_hook_once_per_interactive_process(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d);binary=folder/'fastfetch';binary.write_text('#!/bin/sh\nprintf "FASTFETCH_RUN\\n"\n');binary.chmod(0o755)
            hook=Path(__file__).parent/'fixtures/fastfetch.sh'
            env={**os.environ,'PATH':str(folder)+':'+os.environ['PATH']}
            code='. "$1"; . "$1"; bash --noprofile --norc -ic \'. "$1"; . "$1"\' bash "$1"'
            result=subprocess.run(['bash','--noprofile','--norc','-ic',code,'bash',str(hook)],env=env,capture_output=True,text=True,check=True)
            self.assertEqual(result.stdout.count('FASTFETCH_RUN'),2)
            result=subprocess.run(['bash','--noprofile','--norc','-c','. "$1"; . "$1"','bash',str(hook)],env=env,capture_output=True,text=True,check=True)
            self.assertNotIn('FASTFETCH_RUN',result.stdout)
    def test_flatpak_firefox_system_and_user_only_preserves_data(self):
        class FlatpakRunner(FakeRunner):
            def __init__(self):super().__init__();self.removed=set()
            def __call__(self,args,**kw):
                if 'flatpak' not in args:return super().__call__(args,**kw)
                self.commands.append(args);scope='user' if '--user' in args else 'system'
                if 'uninstall' in args:self.removed.add(scope)
                out='org.gnome.Boxes/x86_64/stable\norg.mozilla.firefox.extra/x86_64/stable\n'
                if scope not in self.removed:out+='org.mozilla.firefox/x86_64/stable\napp/org.mozilla.firefox/x86_64/beta\n'
                return subprocess.CompletedProcess(args,0,out)
        with tempfile.TemporaryDirectory() as temp:
            runner=FlatpakRunner();engine=self.engine(temp,runner)
            (engine.root/'home/test/.local/share/flatpak').mkdir(parents=True)
            user=type('User',(),{'pw_uid':1000,'pw_dir':'/home/test','pw_name':'test'})()
            with patch.object(u.shutil,'which',return_value='/usr/bin/flatpak'),patch.object(u.pwd,'getpwall',return_value=[user]):engine.remove_flatpak_firefox()
            removed=[c for c in runner.commands if 'uninstall' in c]
            self.assertEqual(len(removed),4)
            for c in removed:
                self.assertTrue(c[-1].startswith('app/org.mozilla.firefox/'))
                self.assertNotIn('--delete-data',c);self.assertIn('--no-related',c)
            self.assertTrue(any(c[:3]==['runuser','-u','test'] for c in removed))
    def test_flatpak_missing_skips_and_failed_removal_stops(self):
        with tempfile.TemporaryDirectory() as temp:
            runner=FakeRunner();engine=self.engine(temp,runner)
            with patch.object(u.shutil,'which',return_value=None):engine.remove_flatpak_firefox()
            self.assertEqual(runner.commands,[])
            engine.run=lambda args,**kw:subprocess.CompletedProcess(args,0,'org.mozilla.firefox/x86_64/stable\n')
            with patch.object(u.shutil,'which',return_value='/usr/bin/flatpak'),patch.object(u.pwd,'getpwall',return_value=[]):
                with self.assertRaises(RuntimeError):engine.remove_flatpak_firefox()
    def test_discovered_branding_and_user_desktop_links(self):
        with tempfile.TemporaryDirectory() as temp:
            engine=self.engine(temp,FakeRunner())
            removed=['usr/share/applications/org.kubuntu.manage-software.desktop',
                     'home/test/MyDesk/org.kubuntu.manage-software.desktop',
                     'usr/share/applications/org.kfocus.web.howtos.desktop',
                     'home/test/MyDesk/org.kfocus.web.howtos.desktop',
                     'usr/share/plasma/look-and-feel/org.kubuntulight.desktop/metadata.json',
                     'usr/share/plasma/look-and-feel/org.kubuntudark.desktop/metadata.json',
                     'usr/share/sddm/themes/ubuntu-theme/Main.qml',
                     'usr/share/sddm/themes/kubuntu-light/Main.qml',
                     'usr/share/wallpapers/old-KUBUNTU-wallpaper.jpg',
                     'usr/share/color-schemes/UbuntuLight.colors',
                     'usr/local/share/themes/MyUbuntuTheme/index.theme',
                     'home/test/.local/share/plasma/look-and-feel/org.kubuntu.custom/metadata.json',
                     'home/test/.local/share/applications/org.kubuntu.web.home.desktop',
                     'home/test/MyDesk/org.kubuntu.restore-desktop-links.desktop',
                     'etc/skel/Desktop/org.kubuntu.web.home.desktop',
                     'usr/share/applications/org.kubuntu.restore-desktop-links.desktop',
                     'usr/share/applications/org.kubuntu.web.home.desktop']
            preserved=['usr/share/sddm/themes/ArchiveOS/Main.qml',
                       'usr/share/plasma/look-and-feel/org.archiveos.desktop/metadata.json',
                       'usr/share/wallpapers/ArchiveOS/light.png',
                       'usr/share/themes/Breeze/index.theme',
                       'usr/share/applications/org.kubuntu.driver-manager.desktop',
                       'usr/share/icons/FairyWren_Light/apps/start-here-ubuntu.svg',
                       'usr/share/keyrings/ubuntu-archive-keyring.gpg']
            for rel in removed+preserved:
                p=engine.root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('asset')
            cfg=engine.root/'home/test/.config/user-dirs.dirs';cfg.parent.mkdir(parents=True)
            cfg.write_text('XDG_DESKTOP_DIR="$HOME/MyDesk"\n')
            user=type('User',(),{'pw_uid':1000,'pw_dir':'/home/test'})()
            with patch.object(u.pwd,'getpwall',return_value=[user]):
                engine.cleanup_branding();engine.cleanup_branding()
            for rel in removed:self.assertFalse((engine.root/rel).exists(),rel)
            for rel in preserved:self.assertTrue((engine.root/rel).exists(),rel)
            for rel in removed:self.assertTrue((engine.backup/'files'/rel).exists(),rel)

    def test_branding_scan_does_not_follow_symlinks(self):
        with tempfile.TemporaryDirectory() as temp:
            engine=self.engine(temp,FakeRunner())
            outside=Path(temp)/'outside';outside.mkdir();(outside/'Ubuntu.png').write_text('keep')
            base=engine.root/'usr/share/wallpapers';base.mkdir(parents=True)
            (base/'linked').symlink_to(outside,target_is_directory=True)
            (base/'KubuntuLink').symlink_to(outside,target_is_directory=True)
            with patch.object(u.pwd,'getpwall',return_value=[]):engine.cleanup_branding()
            self.assertTrue((outside/'Ubuntu.png').exists())
            self.assertTrue((base/'linked').is_symlink())
            self.assertFalse((base/'KubuntuLink').is_symlink())

    def engine(self,temp,runner):
        root=Path(temp)/'root';root.mkdir();backup=Path(temp)/'backup';backup.mkdir()
        bundle=Path(os.environ.get('ARCHIVEOS_TEST_BUNDLE','/tmp/archiveos-main-bundle'));manifest=json.loads((bundle/'manifest.json').read_text())
        return u.Updater(bundle,manifest,root,backup,runner,'tr')
    def test_terminal_default_configs_preserve_theme_and_unrelated_shortcuts(self):
        with tempfile.TemporaryDirectory() as temp:
            engine=self.engine(temp,FakeRunner())
            user=type('User',(),{'pw_uid':1000,'pw_gid':1000,'pw_dir':'/home/test'})()
            config=engine.root/'home/test/.config';config.mkdir(parents=True)
            (config/'kdeglobals').write_text('[General]\nColorScheme=ArchiveOSDark\nTerminalApplication=konsole\n[Other]\nKeep=yes\n')
            (config/'kglobalshortcutsrc').write_text('[org.kde.konsole.desktop]\n_launch=Ctrl+Alt+T,Ctrl+Alt+T,Konsole\n[custom]\nother=Meta+E,Meta+E,Keep\nterminal=Ctrl+Alt+T,none,Old\n')
            with patch.object(u.pwd,'getpwall',return_value=[user]),patch.object(u.os,'chown'):
                engine.terminal_defaults();first=(config/'kglobalshortcutsrc').read_text();engine.terminal_defaults()
            self.assertEqual((config/'kglobalshortcutsrc').read_text(),first)
            self.assertEqual(first.count('_launch=Ctrl+Alt+T,'),1)
            self.assertIn('other=Meta+E,Meta+E,Keep',first);self.assertIn('terminal=none,none,Old',first)
            text=(config/'kdeglobals').read_text();self.assertIn('ColorScheme=ArchiveOSDark',text);self.assertIn('TerminalApplication=aos-terminal',text);self.assertIn('Keep=yes',text)
            self.assertEqual((config/'xdg-terminals.list').read_text().splitlines()[0],'aos-terminal.desktop')

    def test_konsole_transition_keeps_kpart_and_blocks_unrelated_removal(self):
        class Runner(FakeRunner):
            def __init__(self,plan):super().__init__();self.plan=plan
            def __call__(self,args,**kwargs):
                result=super().__call__(args,**kwargs)
                if args[:3]==['apt-get','-s','install']:result.stdout=self.plan
                return result
        for plan,allowed in [('Remv konsole [old]\n',True),('Remv konsole\nRemv konsole-kpart\n',False),('Remv plasma-desktop\n',False)]:
            with self.subTest(plan=plan),tempfile.TemporaryDirectory() as temp:
                run=Runner(plan);engine=self.engine(temp,run)
                with patch.object(engine,'remove_flatpak_firefox'),patch.object(engine,'terminal_defaults'):
                    if allowed:
                        engine.apps()
                        command=next(cmd for cmd in run.commands if cmd[:1]==['apt-get'] and 'install' in cmd and '-s' not in cmd)
                        self.assertIn('konsole-',command);self.assertIn('konsole-kpart',command)
                        self.assertIn(['apt-mark','manual','konsole-kpart'],run.commands)
                        self.assertTrue(any(cmd[0]=='update-alternatives' for cmd in run.commands))
                    else:
                        with self.assertRaisesRegex(RuntimeError,'unrelated'):engine.apps()
                        self.assertFalse(any(cmd[:2]==['apt-get','-y'] for cmd in run.commands))

    def test_final_identity_matches_manifest_after_packages_overwrite_release(self):
        with tempfile.TemporaryDirectory() as temp:
            engine=self.engine(temp,FakeRunner())
            for rel in ('etc/os-release','usr/lib/os-release'):
                target=engine.root/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_text('VERSION_ID="old"\n')
            engine.finalize_identity()
            self.assertEqual(u.read_os(engine.root)['VERSION_ID'],engine.m['version'])
            self.assertIn('VERSION_ID="'+engine.m['version']+'"',(engine.root/'usr/lib/os-release').read_text())
            self.assertIn('Version='+engine.m['version'],(engine.root/'etc/xdg/kcm-about-distrorc').read_text())

    def test_snapshot_failure_prevents_repositories_and_upgrade(self):
        with tempfile.TemporaryDirectory() as temp:
            runner=FakeRunner(fail='--create');engine=self.engine(temp,runner)
            with self.assertRaises(RuntimeError):engine.execute()
            self.assertTrue(all(cmd[0]=='timeshift' for cmd in runner.commands));self.assertFalse((engine.root/'etc/apt').exists())
    def test_snapshot_uses_default_ondemand_tag_and_c_locale(self):
        class CompatibleRunner(FakeRunner):
            def __call__(self,args,**kwargs):
                if args[0]=='timeshift':
                    self_env=kwargs.get('env',{})
                    if self_env.get('LC_ALL')!='C':raise RuntimeError('Unstable locale')
                    if '--tags' in args:raise RuntimeError('Explicit O rejected')
                return super().__call__(args,**kwargs)
        with tempfile.TemporaryDirectory() as temp:
            runner=CompatibleRunner();engine=self.engine(temp,runner);engine.snapshot()
            self.assertIn('--create',runner.commands[1]);self.assertNotIn('--tags',runner.commands[1])
            self.assertEqual((engine.backup/'timeshift-snapshot.txt').read_text(),'2026-10-08_03-00-00\n')
    def test_snapshot_without_new_id_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            runner=lambda args,**kwargs:subprocess.CompletedProcess(args,0,'no new snapshots')
            with self.assertRaises(RuntimeError):self.engine(temp,runner).snapshot()
    def test_upgrade_failure_stops_before_branding(self):
        with tempfile.TemporaryDirectory() as temp:
            runner=FakeRunner(fail='upgrade');engine=self.engine(temp,runner)
            with self.assertRaises(RuntimeError):engine.execute()
            self.assertFalse((engine.root/'etc/os-release').exists())
            self.assertFalse(any(cmd[0]=='update-initramfs' for cmd in runner.commands))
    def test_keep_third_party_sources(self):
        text='deb https://archive.ubuntu.com/ubuntu resolute main\ndeb https://example.org/repo stable main\n'
        result=u.filter_sources(text,'.list');self.assertNotIn('archive.ubuntu',result);self.assertIn('example.org',result)
        mixed='Types: deb\nURIs: https://archive.ubuntu.com/ubuntu https://example.org\nSuites: resolute\n'
        with self.assertRaises(ValueError):u.filter_sources(mixed,'.sources')
    def test_transition_allows_replaced_libraries_but_protects_desktop(self):
        u.guard_upgrade_plan('Remv libplasma6 [6.4]\nInst libplasma7 [6.6]\n')
        for name in ['kwin-wayland','sddm','timeshift','linux-image-generic','grub-efi-amd64']:
            with self.assertRaises(RuntimeError):u.guard_upgrade_plan('Remv '+name+' [old]\n')
    def test_questing_is_accepted_for_iso_repository_transition(self):
        import os
        rootstat=os.stat('/')
        with patch.object(u,'read_os',return_value={'ID':'ubuntu','UBUNTU_CODENAME':'questing'}), patch.object(u.os,'stat',return_value=rootstat), patch.object(u.Path,'exists',return_value=False), patch.object(u.Path,'is_file',return_value=True), patch.object(u.shutil,'which',return_value='/usr/bin/tool'), patch.object(u.subprocess,'check_output',side_effect=['btrfs\n','/usr/lib/plymouth/\n','']):
            u.preflight(Path('/unused'),{'ubuntu_codename':'resolute'})
    def test_preflight_accepts_removed_vendor_theme_but_requires_plugin(self):
        rootstat=os.stat('/')
        def existing(path):return str(path) in ('/etc/timeshift/timeshift.json','/usr/lib/plymouth/details.so')
        for plugin_exists in (True,False):
            with patch.object(u,'read_os',return_value={'ID':'ubuntu','UBUNTU_CODENAME':'resolute'}),patch.object(u.os,'stat',return_value=rootstat),patch.object(u.Path,'exists',return_value=False),patch.object(u.Path,'is_file',autospec=True,side_effect=existing if plugin_exists else lambda p:str(p)=='/etc/timeshift/timeshift.json'),patch.object(u.shutil,'which',return_value='/usr/bin/tool'),patch.object(u.subprocess,'check_output',side_effect=['btrfs\n','/usr/lib/plymouth/\n','']):
                if plugin_exists:u.preflight(Path('/unused'),{'ubuntu_codename':'resolute'})
                else:
                    with self.assertRaisesRegex(RuntimeError,'details plugin missing'):u.preflight(Path('/unused'),{'ubuntu_codename':'resolute'})
    def test_required_desktop_removal_stops_transition_and_archiveos(self):
        class UnsafeRunner(FakeRunner):
            def __call__(self,args,**kwargs):
                result=super().__call__(args,**kwargs)
                if args==['apt-get','-s','dist-upgrade']:result.stdout='Remv kwin-wayland [old]\n'
                return result
        with tempfile.TemporaryDirectory() as temp:
            runner=UnsafeRunner();engine=self.engine(temp,runner)
            with self.assertRaises(RuntimeError):engine.upgrade()
            self.assertFalse(any('install' in c or ('dist-upgrade' in c and '-s' not in c) for c in runner.commands))
    def test_iso_sources_replace_questing_after_snapshot_without_extra_backup(self):
        with tempfile.TemporaryDirectory() as temp:
            runner=FakeRunner();engine=self.engine(temp,runner)
            old=engine.root/'etc/apt/sources.list.d/old.sources';old.parent.mkdir(parents=True);old.write_text('Suites: questing\nURIs: https://example.org\n')
            engine.snapshot();engine.repos()
            self.assertFalse(old.exists());self.assertFalse((engine.backup/'files/etc/apt').exists())
            self.assertFalse((engine.backup/'files/usr/share/keyrings').exists())
            self.assertEqual((engine.root/'etc/apt/sources.list').read_bytes(),(engine.bundle/'apt/sources.list').read_bytes())
            self.assertIn('resolute',(engine.root/'etc/apt/sources.list').read_text())
    def test_repositories_are_untouched_without_verified_snapshot(self):
        with tempfile.TemporaryDirectory() as temp:
            runner=FakeRunner();engine=self.engine(temp,runner)
            old=engine.root/'etc/apt/sources.list';old.parent.mkdir(parents=True);old.write_text('questing')
            with self.assertRaises(RuntimeError):engine.repos()
            self.assertEqual(old.read_text(),'questing');self.assertEqual(runner.commands,[])
    def test_archive_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'bad.tar.gz'
            with tarfile.open(p,'w:gz') as tar:
                info=tarfile.TarInfo('../etc/passwd');data=b'bad';info.size=len(data);tar.addfile(info,io.BytesIO(data))
            with self.assertRaises(ValueError):u.validate_overlay(p)
    def test_symlink_parent_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            engine=self.engine(temp,FakeRunner());external=Path(temp)/'external';external.mkdir();(engine.root/'etc').symlink_to(external)
            with self.assertRaises(ValueError):engine.write('etc/os-release',b'bad')
            self.assertEqual(list(external.iterdir()),[])
    def test_tampered_file_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp);(p/'install.sh').write_text('changed')
            with self.assertRaises(ValueError):u.verify(p,{'files':{'install.sh':'0'*64}})
    def test_full_mock_update_preserves_archiveos_and_removes_ubuntu(self):
        with tempfile.TemporaryDirectory() as temp:
            runner=FakeRunner();engine=self.engine(temp,runner)
            legacy=engine.root/'usr/share/plymouth/themes/ubuntu-logo';legacy.mkdir(parents=True);(legacy/'old').write_text('Ubuntu')
            panel=engine.root/'usr/share/wallpapers/Kubuntu';panel.mkdir(parents=True);(panel/'old').write_text('Kubuntu')
            old_logo=engine.root/'usr/share/pixmaps/ubuntu-logo-text-dark.png';old_logo.parent.mkdir(parents=True);old_logo.write_bytes(b'Ubuntu artwork')
            shell=engine.root/'etc/bash.bashrc';shell.parent.mkdir(exist_ok=True);shell.write_text('# Existing shell settings\n')
            hook=engine.root/'usr/share/initramfs-tools/hooks/plymouth';hook.parent.mkdir(parents=True)
            hook.write_text('#!/bin/sh\nset -e\ncp -dRp "${THEMES}/details" "${DESTDIR}/${THEMES}"\ncp -dRp "${THEMES}/text" "${DESTDIR}/${THEMES}"\n');hook.chmod(0o755)
            for name in u.PLYMOUTH_REMOVE:
                folder=engine.root/'usr/share/plymouth/themes'/name;folder.mkdir(parents=True);(folder/(name+'.plymouth')).write_text('vendor theme')
            with patch.object(u.pwd,'getpwall',return_value=[]):engine.execute()
            for name in u.PLYMOUTH_REMOVE:
                self.assertFalse((engine.root/'usr/share/plymouth/themes'/name).exists())
                self.assertIn(['update-alternatives','--remove','text.plymouth',f'/usr/share/plymouth/themes/{name}/{name}.plymouth'],runner.commands)
            self.assertIn(['update-alternatives','--set','text.plymouth','/usr/share/plymouth/themes/ArchiveOS-Text/ArchiveOS-Text.plymouth'],runner.commands)
            self.assertIn('ModuleName=details',(engine.root/'usr/share/plymouth/themes/ArchiveOS-Text/ArchiveOS-Text.plymouth').read_text())
            # Exercise the adapted hook with absent vendor dirs, rather than just inspecting text.
            env=dict(os.environ,THEMES=str(engine.root/'usr/share/plymouth/themes'),DESTDIR=str(engine.root/'initrd'))
            subprocess.run(['sh',str(hook)],env=env,check=True)
            self.assertEqual(hook.stat().st_mode&0o777,0o755)
            self.assertFalse(legacy.exists());self.assertFalse(panel.exists())
            self.assertEqual(old_logo.read_bytes(),(engine.root/'usr/share/pixmaps/archiveos.png').read_bytes())
            self.assertTrue((engine.backup/'files/usr/share/plymouth/themes/ubuntu-logo/old').exists())
            self.assertTrue((engine.root/'usr/share/plymouth/themes/ArchiveOS/ArchiveOS.script').exists())
            shared=engine.root/'usr/share/plasma/look-and-feel'/u.SPLASH_ID
            self.assertTrue((shared/'contents/splash/Splash.qml').exists())
            for theme in ('org.archiveos.desktop','org.archiveos-dark.desktop'):
                root=engine.root/'usr/share/plasma/look-and-feel'/theme
                self.assertEqual((root/'contents/splash').exists(),theme==u.SPLASH_ID)
                self.assertIn('Theme='+u.SPLASH_ID,(root/'contents/defaults').read_text())
            config=(engine.root/'etc/default/grub.d/zzzz-archiveos-branding.cfg').read_text()
            self.assertIn('mitigations=off',config);self.assertIn('rootflags=subvol=@',config);self.assertNotIn('nosplash',config);self.assertNotIn('plymouth.enable',config);self.assertIn('splash',config)
            self.assertIn('Existing shell settings',shell.read_text())
            self.assertIn('DISTRIB_CODENAME=resolute',(engine.root/'etc/lsb-release').read_text())
            self.assertIn('org.archiveos.defaultPanel',(engine.root/'usr/share/plasma/look-and-feel/org.archiveos.desktop/contents/layouts/org.kde.plasma.desktop-layout.js').read_text())
            self.assertLess(next(i for i,c in enumerate(runner.commands) if c[:2]==['timeshift','--create']),next(i for i,c in enumerate(runner.commands) if c[0]=='apt-get'))
            clean=runner.commands.index(['apt-get','clean']);install=next(i for i,c in enumerate(runner.commands) if c[0]=='apt-get' and 'install' in c);self.assertLess(clean,install)
            self.assertIn(['apt-get','-s','dist-upgrade'],runner.commands)
            self.assertEqual(runner.commands[-3:], [['update-initramfs','-u','-k','all'],['/usr/bin/python3','/usr/local/libexec/archiveos-kernel-cleanup.py','--apply'],['update-grub']])
            self.assertTrue((engine.root/'etc/apt/apt.conf.d/99archiveos-kernel-cleanup').exists())
class ProgressTests(unittest.TestCase):
    def test_capture_streams_before_command_exits_and_preserves_return(self):
        # The child cannot finish until terminal output has been observed.
        import sys
        with tempfile.TemporaryDirectory() as temp:
            marker=Path(temp)/'seen';log=Path(temp)/'run.log'
            class WatchingOutput(io.StringIO):
                def write(self,text):
                    if 'early\r' in text:marker.touch()
                    return super().write(text)
            output=WatchingOutput()
            code="import sys,time,pathlib; sys.stdout.write('early\\r'); sys.stdout.flush(); p=pathlib.Path(sys.argv[1]); end=time.monotonic()+3;\nwhile not p.exists() and time.monotonic()<end: time.sleep(.01)\nassert p.exists(), 'output was buffered'; print('finished ü')"
            with patch.object(u.sys,'stdout',output):
                result=u.Runner(log)([sys.executable,'-c',code,str(marker)],capture=True)
            self.assertIn('early\r',result.stdout);self.assertIn('finished ü',result.stdout)
            self.assertIn('finished ü',output.getvalue());self.assertIn('finished ü',log.read_text())
    def test_silent_command_ticks_and_failure_is_reported(self):
        import sys
        with tempfile.TemporaryDirectory() as temp:
            progress=u.Progress('tr');log=Path(temp)/'run.log'
            with patch.object(u.sys,'stdout',io.StringIO()), patch.object(progress,'render') as tick:
                with self.assertRaises(RuntimeError):
                    u.Runner(log,progress)([sys.executable,'-c','import time,sys; time.sleep(.5); sys.exit(7)'])
            self.assertGreaterEqual(tick.call_count,1)
    def test_progress_languages_redirected_without_escape_codes(self):
        for lang,label in [('tr','Aşama ilerlemesi'),('en','Stage progress')]:
            output=io.StringIO()
            with patch.object(u.sys,'stdout',output):
                progress=u.Progress(lang);progress.stage(80,'files');progress.stage(100,'done')
            text=output.getvalue();self.assertIn(label,text);self.assertIn('100%',text)
            self.assertNotIn('\033',text);self.assertNotIn('\r',text)
    def test_overlay_lists_files_and_progress_completes_only_on_success(self):
        with tempfile.TemporaryDirectory() as temp:
            engine=UpdateTests().engine(temp,FakeRunner());output=io.StringIO()
            with patch.object(u.sys,'stdout',output), patch.object(u.pwd,'getpwall',return_value=[]):engine.execute()
            text=output.getvalue();self.assertIn('Dosya uygulanıyor: etc/os-release',text)
            self.assertIn('Dizin hazırlanıyor:',text);self.assertIn('100%',text)
        with tempfile.TemporaryDirectory() as temp:
            engine=UpdateTests().engine(temp,FakeRunner(fail='upgrade'));output=io.StringIO()
            with patch.object(u.sys,'stdout',output):
                with self.assertRaises(RuntimeError):engine.execute()
            self.assertNotIn('100%',output.getvalue())
if __name__=='__main__':unittest.main()
