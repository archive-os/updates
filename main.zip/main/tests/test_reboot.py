import importlib.util
import os
from pathlib import Path
import subprocess
import unittest
from unittest.mock import patch
from types import SimpleNamespace

base=Path(__file__).parents[1]
def module(name,file):
    spec=importlib.util.spec_from_file_location(name,(base/file if str(file)=='reboot.py' else base/'helpers'/file))
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result
u=module('restart_updater','update.py')

class RebootTests(unittest.TestCase):
    def test_pkexec_uid_and_active_graphical_session(self):
        account=SimpleNamespace(pw_uid=1000,pw_name='desktop',pw_dir='/home/desktop')
        with patch.dict(os.environ,{'PKEXEC_UID':'1000'},clear=True),patch.object(u.pwd,'getpwuid',return_value=account):
            self.assertIs(u.desktop_identity(),account)
        with patch.dict(os.environ,{},clear=True),patch.object(u.pwd,'getpwuid',return_value=account),patch.object(u.subprocess,'check_output',side_effect=['3 1000 desktop seat0 tty2\n','Active=yes\nType=wayland\nUser=1000\n']):
            self.assertIs(u.desktop_identity(),account)

    def test_clean_qt_environment_and_restart_result(self):
        account=SimpleNamespace(pw_uid=1000,pw_name='desktop',pw_dir='/home/desktop')
        env={'HOME':account.pw_dir,'DISPLAY':':0','QT_QPA_PLATFORM':'xcb'}
        with patch.dict(os.environ,{'QT_PLUGIN_PATH':'/invalid/qt5','PYTHONPATH':'/invalid'},clear=False),patch.object(u,'desktop_identity',return_value=account),patch.object(u,'desktop_environment',return_value=env),patch.object(u.subprocess,'run') as run:
            for code,expected in [(0,False),(10,True)]:
                run.return_value=subprocess.CompletedProcess([],code)
                self.assertEqual(u.reboot_question(Path('/bundle'),'tr'),expected)
                args=run.call_args.args[0]
                self.assertIn('-i',args);self.assertIn('--request-only',args)
                self.assertFalse(any(item.startswith(('QT_PLUGIN_PATH=','PYTHONPATH=')) for item in args))
                self.assertNotIn('reboot',args)

    def test_gui_failure_does_not_fail_completed_update(self):
        account=SimpleNamespace(pw_uid=1000,pw_name='desktop',pw_dir='/home/desktop')
        with patch.object(u,'desktop_identity',return_value=account),patch.object(u,'desktop_environment',return_value={'QT_QPA_PLATFORM':'xcb'}),patch.object(u.subprocess,'run',return_value=subprocess.CompletedProcess([],1)),patch.object(u.sys.stdin,'isatty',return_value=True),patch('builtins.input',return_value='e'):
            self.assertTrue(u.reboot_question(Path('/bundle'),'tr'))

    def test_session_manager_environment_filters_stale_qt(self):
        account=SimpleNamespace(pw_uid=987654,pw_name='desktop',pw_dir='/nonexistent')
        with patch.dict(os.environ,{'QT_QPA_PLATFORM':'wayland','QT_PLUGIN_PATH':'/old'},clear=True),patch.object(u.subprocess,'check_output',return_value='DISPLAY=:1\nXAUTHORITY=/run/user/987654/auth\nQT_PLUGIN_PATH=/old\nQT_QPA_PLATFORM=wayland\n'):
            env=u.desktop_environment(account)
            self.assertEqual(env['DISPLAY'],':1');self.assertEqual(env['QT_QPA_PLATFORM'],'xcb')
            self.assertNotIn('QT_PLUGIN_PATH',env)

    def test_dialog_buttons_return_choice_without_reboot(self):
        from PyQt6.QtWidgets import QApplication
        app=QApplication.instance() or QApplication([])
        r=module('restart_dialog','reboot.py')
        with patch('subprocess.run') as run:
            dialog=r.RebootDialog('tr','light',request_only=True);dialog.restart.click()
            self.assertEqual(dialog.result(),10)
            dialog=r.RebootDialog('en','light');dialog.later.click()
            self.assertEqual(dialog.result(),0)
            dialog=r.RebootDialog('tr','light',preview=True);dialog.restart.click()
            self.assertEqual(dialog.result(),0);run.assert_not_called()
            from PyQt6.QtCore import QProcess
            with patch.object(QProcess,'start') as start:
                dialog=r.RebootDialog('tr','light');dialog.restart.click()
                start.assert_called_once_with('systemctl',['reboot'])
                dialog.restart_failed()
                self.assertTrue(dialog.restart.isEnabled());self.assertTrue(dialog.error.text())

if __name__=='__main__':unittest.main()
