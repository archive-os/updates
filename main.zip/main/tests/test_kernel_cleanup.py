import importlib.util,tempfile,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('kernel_cleanup',Path(__file__).parents[1]/'helpers/kernel_cleanup.py');k=importlib.util.module_from_spec(spec);spec.loader.exec_module(k)
class KernelTests(unittest.TestCase):
    def fixture(self,root):
        packages=[]
        for abi in ('6.17.0-35-generic','6.17.0-41-generic','7.0.0-38-generic'):
            for prefix in ('linux-image-','linux-modules-','linux-modules-extra-','linux-headers-','linux-modules-nvidia-580-open-'):
                packages.append((prefix+abi,'installed'))
            packages.append(('linux-headers-'+abi.rsplit('-',1)[0],'installed'))
            for prefix in ('vmlinuz-','initrd.img-'):
                p=root/'boot'/(prefix+abi);p.parent.mkdir(exist_ok=True);p.write_text('boot')
        packages += [('linux-image-generic','installed'),('linux-headers-generic-hwe-26.04','installed'),('linux-modules-nvidia-580-open-generic-hwe-26.04','installed')]
        return packages
    def test_purge_617_after_booting_7_preserves_tracking_packages(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);packages=self.fixture(root)
            selected=k.candidates(packages,'7.0.0-38-generic',root)
            self.assertEqual(len(selected),12)
            self.assertTrue(all('6.17.' in p for p in selected))
    def test_running_old_kernel_retained_until_reboot(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);packages=self.fixture(root)
            selected=k.candidates(packages,'6.17.0-41-generic',root)
            self.assertEqual(len(selected),6);self.assertTrue(all('6.17.0-35' in p for p in selected))
    def test_missing_replacement_initrd_prevents_purge(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);packages=self.fixture(root);(root/'boot/initrd.img-7.0.0-38-generic').unlink()
            self.assertEqual(k.candidates(packages,'6.17.0-41-generic',root),[])
    def test_dependency_removal_and_unexpected_install_rejected(self):
        selected=['linux-image-6.17.0-35-generic']
        k.guard('Remv '+selected[0]+' [1]\n',selected)
        k.guard('Purg '+selected[0]+'\n',selected)
        for plan in ('Remv '+selected[0]+'\nRemv linux-image-generic\n','Remv '+selected[0]+'\nRemv plasma-desktop\n','Inst linux-image-new\n',''):
            with self.assertRaises(RuntimeError):k.guard(plan,selected)
    def test_shared_headers_preserved_for_other_flavor(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);packages=self.fixture(root)
            abi='6.17.0-41-lowlatency'
            packages.append(('linux-image-'+abi,'installed'))
            for prefix in ('vmlinuz-','initrd.img-'):(root/'boot'/(prefix+abi)).write_text('boot')
            self.assertNotIn('linux-headers-6.17.0-41',k.candidates(packages,'7.0.0-38-generic',root))
if __name__=='__main__':unittest.main()
