import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock,patch
from PyQt6.QtTest import QTest
from PyQt6.QtWidgets import QApplication

base=Path(__file__).parents[1]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,(base/path if str(path)=='reboot.py' else base/'helpers'/path));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
u=module('screen_updater','update.py');g=module('screen_gui','update_screen.py')
TemporaryDirectory=tempfile.TemporaryDirectory

class ScreenTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])
    def test_tr_en_progress_live_terminal_and_completion_waits_for_restart(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);status=root/'status.json';log=root/'update.log';log.write_text('\x1b[31mAPT test\x1b[0m\n')
            for lang in ('tr','en'):
                status.write_text(json.dumps({'percent':63,'label':'Test','state':'running'}))
                w=g.UpdateScreen(status,log,root/'logo.png',lang);w.resize(1280,800);w.show();QTest.qWait(30)
                self.assertEqual(w.title.text(),g.TEXT[lang][0]);self.assertEqual(w.progress.value(),63)
                w.toggle.click();self.assertTrue(w.terminal.isVisible());self.assertIn('APT test',w.terminal.toPlainText());self.assertNotIn('\x1b',w.terminal.toPlainText())
                with log.open('a') as stream:stream.write('next line\n')
                w.poll();self.assertIn('next line',w.terminal.toPlainText())
                w.toggle.click();self.assertFalse(w.terminal.isVisible())
                w.close();self.assertTrue(w.isVisible())
                status.write_text(json.dumps({'percent':100,'state':'complete'}));w.poll();self.assertTrue(w.isVisible());self.assertEqual(w.title.text(),g.TEXT[lang][5])
                status.write_text(json.dumps({'state':'close'}));w.poll();self.assertFalse(w.isVisible());w.deleteLater()
    def test_small_screen_log_toggle_resize_and_restart_prompt(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);status=root/'status.json';log=root/'update.log'
            status.write_text(json.dumps({'percent':90,'label':'Applying '+('long-path/'*30),'state':'running'}));log.write_text('first\n')
            w=g.UpdateScreen(status,log,base/'helpers/aos-menu.png','tr');w.resize(640,480);w.show();QTest.qWait(40)
            w.toggle.click();QTest.qWait(40)
            self.assertGreaterEqual(w.center.width(),600);self.assertGreaterEqual(w.title.height(),w.title.fontMetrics().height());self.assertLessEqual(w.height(),480);self.assertTrue(w.rect().contains(w.toggle.geometry()))
            self.assertTrue(w.rect().contains(w.terminal.geometry()));self.assertTrue(w.terminal.isVisible())
            self.assertGreaterEqual(w.subtitle.height(),w.subtitle.heightForWidth(w.subtitle.width()))
            replacement=root/'new.log';replacement.write_text('replacement log line\n');replacement.replace(log);w.read_log()
            self.assertIn('replacement log line',w.terminal.toPlainText())
            status.write_text(json.dumps({'state':'complete','percent':100}));w.poll()
            status.write_text(json.dumps({'state':'prompt','percent':100}));w.poll();self.assertFalse(w.isVisible())
            status.write_text(json.dumps({'state':'close'}));w.poll();w.deleteLater()

    def session(self,root):
        bundle=root/'bundle';(bundle/'helpers').mkdir(parents=True)
        for name in ('update_screen.py','aos-menu.png'):(bundle/'helpers'/name).write_text('test')
        self.enterContext(patch.object(u.tempfile,'TemporaryDirectory',side_effect=lambda **kwargs:TemporaryDirectory(dir=root,prefix='screen-')))
        progress=u.Progress();session=u.UpdateScreenSession(bundle,'tr',root/'update.log',progress)
        process=MagicMock();process.stdout=io.StringIO('ARCHIVEOS_UI_READY\n');process.poll.return_value=None
        return session,process
    def test_plasma_stops_and_returns_after_restart_question_without_touching_kwin(self):
        with tempfile.TemporaryDirectory() as tmp:
            session,process=self.session(Path(tmp));account=SimpleNamespace(pw_name='desktop')
            with patch.object(u,'desktop_identity',return_value=account),patch.object(u,'desktop_environment',return_value={'DISPLAY':':0','QT_QPA_PLATFORM':'xcb'}),patch.object(u.subprocess,'Popen',return_value=process),patch.object(u.select,'select',return_value=([process.stdout],[],[])),patch.object(u.subprocess,'run',return_value=subprocess.CompletedProcess([],0)) as run:
                self.assertTrue(session.start());session.progress.stage(42,'phase')
                self.assertEqual(json.loads((session.directory/'status.json').read_text())['percent'],42)
                session.complete();self.assertTrue(session.restore_needed)
                self.assertFalse(any('start' in call.args[0] for call in run.call_args_list))
                session.close()
                commands=[call.args[0] for call in run.call_args_list]
                self.assertTrue(any('stop' in cmd and 'plasma-plasmashell.service' in cmd for cmd in commands))
                self.assertTrue(any('start' in cmd and 'plasma-plasmashell.service' in cmd for cmd in commands))
                self.assertFalse(any('kwin' in arg for cmd in commands for arg in cmd));self.assertFalse(session.restore_needed)
    def test_failure_after_shell_stop_still_restores_shell(self):
        with tempfile.TemporaryDirectory() as tmp:
            session,process=self.session(Path(tmp));account=SimpleNamespace(pw_name='desktop')
            def command(args,**kwargs):
                if 'stop' in args:raise subprocess.CalledProcessError(1,args)
                return subprocess.CompletedProcess(args,0)
            with patch.object(u,'desktop_identity',return_value=account),patch.object(u,'desktop_environment',return_value={'QT_QPA_PLATFORM':'wayland'}),patch.object(u.subprocess,'Popen',return_value=process),patch.object(u.select,'select',return_value=([process.stdout],[],[])),patch.object(u.subprocess,'run',side_effect=command) as run:
                with self.assertRaises(subprocess.CalledProcessError):session.start()
                session.close()
                self.assertTrue(any('start' in call.args[0] for call in run.call_args_list))
    def test_real_gui_handshake_progress_and_close_with_shell_commands_mocked(self):
        with TemporaryDirectory() as tmp:
            root=Path(tmp);bundle=root/'bundle';(bundle/'helpers').mkdir(parents=True)
            import shutil
            shutil.copy2(base/'helpers/update_screen.py',bundle/'helpers/update_screen.py')
            shutil.copy2(base/'helpers/aos-menu.png',bundle/'helpers/aos-menu.png')
            session=u.UpdateScreenSession(bundle,'tr',root/'update.log',u.Progress())
            account=SimpleNamespace(pw_name='desktop',pw_uid=1000)
            with patch.object(u.tempfile,'TemporaryDirectory',side_effect=lambda **kwargs:TemporaryDirectory(dir=root)),patch.object(u,'desktop_identity',return_value=account),patch.object(u,'desktop_environment',return_value={'QT_QPA_PLATFORM':'offscreen'}),patch.object(session,'command',side_effect=lambda *args:list(args)),patch.object(u.subprocess,'run',return_value=subprocess.CompletedProcess([],0)):
                try:
                    self.assertTrue(session.start());session.progress.stage(70,'Fixture update')
                    session.complete();self.assertIsNone(session.process.poll())
                finally:session.close()
                self.assertEqual(session.process.returncode,0);self.assertFalse(session.restore_needed)

    def test_screen_failure_watch_restores_plasma(self):
        with tempfile.TemporaryDirectory() as tmp:
            session,process=self.session(Path(tmp));session.account=SimpleNamespace(pw_name='desktop');session.env={};session.restore_needed=True;session.process=process;process.poll.return_value=1
            session.stop_watch=MagicMock();session.stop_watch.wait.return_value=False
            with patch.object(u.subprocess,'run',return_value=subprocess.CompletedProcess([],0)) as run:
                session.watch_screen();self.assertFalse(session.restore_needed);self.assertIn('start',run.call_args.args[0])
if __name__=='__main__':unittest.main()
