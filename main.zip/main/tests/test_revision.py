import importlib.util,json,os,subprocess,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('revision_update',Path(__file__).parents[1]/'helpers/update.py');u=importlib.util.module_from_spec(spec);spec.loader.exec_module(u)

class RevisionTests(unittest.TestCase):
    def test_locale_precedence(self):
        for env,expected in [({'LANG':'en_US','LANGUAGE':'tr:en'},'tr'),({'LANG':'tr_TR','LC_MESSAGES':'en_US'},'en'),({'LANGUAGE':'tr','LC_ALL':'C'},'en'),({'LANG':'fr_FR'},'en')]:
            self.assertEqual(u.language(env),expected)
    def test_btrfs_fast_path_requires_at_root_and_same_backup_device(self):
        engine=object.__new__(u.Updater);engine.root=Path('/');engine.detail=lambda *args:None
        cfg=json.dumps({'btrfs_mode':'false','backup_device_uuid':'same'})
        for fs,subvol,uuid,expected in [('btrfs','/@','same',['--btrfs']),('ext4','/','same',[]),('btrfs','/other','same',[]),('btrfs','/@','external',[])]:
            data=json.dumps({'filesystems':[{'fstype':fs,'fsroot':subvol,'uuid':uuid}]})
            with patch.object(Path,'read_text',return_value=cfg),patch.object(u.subprocess,'check_output',return_value=data):self.assertEqual(engine.snapshot_options(),expected)
    def test_kde_run_action_mask_keeps_archiveos_actions(self):
        with tempfile.TemporaryDirectory() as tmp:
            engine=object.__new__(u.Updater);engine.root=Path(tmp)/'root';engine.backup=Path(tmp)/'backup';engine.backup.mkdir();engine.detail=lambda *args:None
            folder=engine.root/'usr/share/kio/servicemenus';folder.mkdir(parents=True)
            (folder/'konsolerun.desktop').write_text('[Desktop Entry]\nExec=konsole --hold -e %f\n')
            (folder/'aos-terminal-folder.desktop').write_text('[Desktop Entry]\nExec=aos-terminal --working-directory %f\n')
            config=engine.root/'etc/skel/.config/dolphinrc';config.parent.mkdir(parents=True)
            config.write_text('[ContextMenu]\nShowOpenTerminal=true\nShowCopyLocation=false\n[General]\nViewMode=Details\n')
            with patch.object(u.pwd,'getpwall',return_value=[]):
                engine.suppress_kde_terminal_actions();first=config.read_bytes();engine.suppress_kde_terminal_actions()
            self.assertEqual(first,config.read_bytes());self.assertIn('ShowOpenTerminal=false',config.read_text())
            self.assertIn('ShowCopyLocation=false',config.read_text());self.assertIn('ViewMode=Details',config.read_text())
            target=engine.root/'etc/skel/.local/share/kio/servicemenus'
            self.assertIn('Hidden=true',(target/'konsolerun.desktop').read_text());self.assertIn('Exec=aos-terminal',(target/'aos-terminal-folder.desktop').read_text());self.assertTrue((target/'aos-terminal-folder.desktop').stat().st_mode&0o100)
    def test_cleanup_unblocks_after_gui_dies(self):
        progress=u.Progress();s=u.UpdateScreenSession(Path('/bundle'),'en',Path('/tmp/log'),progress);s.account=SimpleNamespace(pw_name='desktop');s.env={};s.shortcuts_blocked=True
        with patch.object(u.subprocess,'run',return_value=subprocess.CompletedProcess([],0)) as run:
            s.restore_shell();self.assertIn('org.kde.KGlobalAccel.blockGlobalShortcuts',run.call_args.args[0]);self.assertEqual(run.call_args.args[0][-1],'false');self.assertFalse(s.shortcuts_blocked)

class ThemeAndLockTests(unittest.TestCase):
    def test_reboot_theme_uses_user_scheme_before_defaults(self):
        from PyQt6.QtWidgets import QApplication
        app=QApplication.instance() or QApplication([])
        spec=importlib.util.spec_from_file_location('revision_reboot',Path(__file__).parents[1]/'reboot.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
        with tempfile.TemporaryDirectory() as tmp,patch.dict(os.environ,{'XDG_CONFIG_HOME':tmp}):
            base=Path(tmp);(base/'kdedefaults').mkdir();(base/'kdedefaults/kdeglobals').write_text('[General]\nColorScheme=ArchiveOSDark\n')
            for scheme,result in [('ArchiveOSWhite','light'),('ArchiveOSDark','dark')]:
                (base/'kdeglobals').write_text('[General]\nColorScheme='+scheme+'\n');self.assertEqual(r.system_theme(app),result)
    def test_kwin_rules_preserve_user_rules_and_force_geometry_and_shortcuts(self):
        from PyQt6.QtWidgets import QApplication
        from PyQt6.QtCore import QSettings
        from PyQt6.QtDBus import QDBusMessage
        from unittest.mock import MagicMock
        app=QApplication.instance() or QApplication([])
        spec=importlib.util.spec_from_file_location('revision_screen',Path(__file__).parents[1]/'helpers/update_screen.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
        with tempfile.TemporaryDirectory() as tmp:
            home=Path(tmp);(home/'.config').mkdir();path=home/'.config/kwinrulesrc';path.write_text('[General]\nrules=personal\n[personal]\nDescription=keep me\n')
            interface=MagicMock();interface.call.return_value.type.return_value=QDBusMessage.MessageType.ReplyMessage
            with patch.object(g.Path,'home',return_value=home),patch('PyQt6.QtDBus.QDBusInterface',return_value=interface):g.desktop_lock(app)
            config=QSettings(str(path),QSettings.Format.IniFormat)
            self.assertEqual(config.value('personal/Description'),'keep me')
            self.assertIn('personal',config.value('rules',type=list))
            self.assertEqual(config.value('archiveos-update-screen/positionrule',type=int),2)
            self.assertTrue(config.value('archiveos-update-screen/disableglobalshortcuts',type=bool))
            self.assertTrue(config.value('archiveos-update-screen/fullscreen',type=bool))
            interface.call.assert_any_call('blockGlobalShortcuts',True)

class SnapshotAndVersionTests(unittest.TestCase):
    def test_quiet_snapshot_keeps_fresh_id_verification(self):
        from test_update import UpdateTests,FakeRunner
        with tempfile.TemporaryDirectory() as tmp:
            runner=FakeRunner();engine=UpdateTests().engine(tmp,runner);engine.snapshot()
            self.assertIn('--quiet',next(cmd for cmd in runner.commands if '--create' in cmd))
            self.assertTrue((engine.backup/'timeshift-snapshot.txt').is_file())
    def test_identity_repairs_stale_json_without_losing_other_fields(self):
        from test_update import UpdateTests,FakeRunner
        with tempfile.TemporaryDirectory() as tmp:
            engine=UpdateTests().engine(tmp,FakeRunner());path=engine.root/'var/lib/archiveos/version.json';path.parent.mkdir(parents=True);path.write_text('{"version":"2.0.1","custom":"keep"}')
            with patch.object(u.pwd,'getpwall',return_value=[]):engine.finalize_identity()
            self.assertEqual(json.loads(path.read_text()),{'version':'2.0.2','custom':'keep'})
            self.assertEqual(json.loads((engine.root/'etc/archiveos-version.json').read_text())['version'],'2.0.2')

class ShortcutContinuityTests(unittest.TestCase):
    def test_terminal_defaults_do_not_restart_shortcuts_during_locked_update(self):
        from test_update import UpdateTests,FakeRunner
        import test_update
        with tempfile.TemporaryDirectory() as tmp:
            runner=FakeRunner();engine=UpdateTests().engine(tmp,runner);root=engine.root;engine.root=Path('/');engine.target=lambda rel:root/rel
            account=SimpleNamespace(pw_name='desktop')
            with patch.dict(os.environ,{'ARCHIVEOS_UPDATE_DESKTOP_LOCKED':'1'}),patch.object(test_update.u,'desktop_identity',return_value=account),patch.object(test_update.u,'desktop_environment',return_value={}),patch.object(u.pwd,'getpwall',return_value=[]):engine.terminal_defaults()
            self.assertFalse(any('stop' in cmd or 'start' in cmd for cmd in runner.commands))
