# One invocation per interactive Bash process; do not export this marker.
case $- in
    *i*)
        if [ "${_ARCHIVEOS_FASTFETCH_PID:-}" != "$BASHPID" ] && command -v fastfetch >/dev/null; then
            _ARCHIVEOS_FASTFETCH_PID=$BASHPID
            fastfetch
        fi
        ;;
esac
