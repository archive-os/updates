# ArchiveOS 2.0.2 package revision — 18 October 2026

Implemented in this bundle:

- Timeshift runs with `--quiet` to avoid forwarding every copied file through the PTY, terminal and GUI log. A root Btrfs `@` subvolume uses native snapshots only when the configured backup UUID matches the root filesystem; configured external destinations and other layouts are preserved. Fresh snapshot creation and ID verification remain mandatory. First rsync backups still have to copy the system; no timing claim has been made.
- KDE's legacy Konsole run/open service menus receive local hidden overrides. ArchiveOS Terminal's folder and script actions remain available. Existing users and the skeleton are covered.
- Reboot UI uses the current KDE light/dark scheme and a white/black palette, including user, KDE defaults and installed color-scheme lookup. TR/EN buttons and text are retained.
- Both os-release files, LSB/KDE identity and application version JSON records are synchronized to 2.0.2; unrelated JSON fields are preserved. Login banners also identify ArchiveOS 2.0.2.
- The update window is frameless, with a KWin rule scoped to its application forcing fullscreen position/size and disabling global shortcuts. Runtime shortcut blocking is released on normal close, GUI failure or lost updater process. Shortcut configuration reload is deferred until the update UI exits so installing terminal defaults cannot temporarily enable shortcuts mid-update. Existing KWin rules are retained.
- Terminal 2.1.6 opens at 960×540. Tabs are wider and rounded, with inset close buttons. Session switches use a short crossfade controlled by the animation preference. Dragging displays a preview and a new-window hint while preserving the running session.
- Search uses a larger SVG magnifier, a readable theme-aware search bar and bundled Turkish Konsole translations, including native option menus and tooltips. Other system languages use the English interface.
- The autostart service is named **ArchiveOS Theme Wallpaper Service**, with a matching blue SVG icon.

## Verification

62 updater/kernel/reboot/screen/revision tests passed against the delivered helper paths. 17 terminal Qt/PTY tests were run against the extracted final DEB, including session continuity, detach, search, crossfade, drag hint, themes, busy-shell behavior and clipboard handling. Python compilation, shell syntax, DEB metadata/MD5, overlay identity, manifest SHA-256 and TR/EN dry-run checks were also performed.

Reproduce updater tests:

```sh
QT_QPA_PLATFORM=offscreen ARCHIVEOS_TEST_BUNDLE="$PWD" /usr/bin/python3 -m unittest discover -s tests -v
./install.sh --dry-run --lang tr
./install.sh --dry-run --lang en
sha256sum -c SHA256SUMS
```

Terminal sources and tests are in the DEB's `/usr/share/doc/aos-terminal/source.tar.gz`. Preview images are in `validation/previews`.

The host was not updated. No real Timeshift snapshot, APT upgrade, reboot, physical Dolphin interaction or KDE Wayland/X11 shortcut/move test was performed. Snapshot timing and live compositor behavior remain to be verified on the installed target or a VM. No universal performance improvement is claimed for the first rsync snapshot.

References used for implementation: [KDE KWin scripting](https://develop.kde.org/docs/plasma/kwin/api/), [KGlobalAccel D-Bus interface](https://github.com/KDE/kglobalaccel/blob/master/src/org.kde.KGlobalAccel.xml), [Timeshift source](https://github.com/linuxmint/timeshift).

## Fastfetch version and update notice

The overlay's Fastfetch OS format previously contained a literal `ArchiveOS v2.0.1 (resolute)` despite both os-release files identifying 2.0.2. It now displays `ArchiveOS v2.0.2 (resolute)`. Existing user configurations receive this same file through the updater. Verification checks this display against the manifest version and codename before any system update.

The update screen now explains in Turkish and English that the system may appear frozen, must not be turned off and can be restored with the Timeshift snapshot if an error occurs. Compact text and log sizing keep the notice visible at 640×480 with the real logo and terminal log open. TR/EN offscreen renders and the installed Fastfetch binary were checked; the overlay comparison confirmed that only `etc/fastfetch/config.jsonc` changed inside the archive. The updater suite now contains 63 tests, including stale Fastfetch version rejection and existing-user configuration checks. No host update or actual Timeshift restoration was performed.
