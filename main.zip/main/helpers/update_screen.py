#!/usr/bin/python3
import argparse
import codecs
import json
import os
from pathlib import Path
import re
import sys
import tempfile
from PyQt6.QtCore import Qt,QTimer,QEvent,QSettings
from PyQt6.QtGui import QIcon,QPixmap,QTextCursor
from PyQt6.QtWidgets import QApplication,QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QProgressBar,QPlainTextEdit,QSizePolicy

TEXT={
    'tr':('ArchiveOS Güncelleniyor','Güncelleme zaman alabilir ve sistem donmuş gibi görünebilir.\nSistemi sakın kapatmayın.\nHata olursa Timeshift yedeğiyle geri dönebilirsiniz.','Terminali aç','Terminali kapat','Güncelleme hazırlanıyor…','Güncelleme tamamlandı','Yeniden başlatma seçiminiz bekleniyor.','Güncelleme durduruldu'),
    'en':('Updating ArchiveOS','The update may take time and the system may appear frozen.\nDo not turn off your computer.\nIf an error occurs, you can restore your Timeshift snapshot.','Open terminal','Close terminal','Preparing update…','Update complete','Waiting for your restart choice.','Update stopped')}

def minimize_script(pid):
    return f'''var windows=workspace.windowList();
for (var i=0;i<windows.length;i++) {{
    var window=windows[i];
    if (window.pid!={int(pid)} && window.minimizable && !window.specialWindow) window.minimized=true;
}}
'''


def minimize_other_windows():
    from PyQt6.QtDBus import QDBusConnection,QDBusInterface,QDBusMessage
    bus=QDBusConnection.sessionBus()
    interface=QDBusInterface('org.kde.KWin','/Scripting','org.kde.kwin.Scripting',bus)
    interface.setTimeout(5000)
    if not interface.isValid():raise RuntimeError('KWin window control is unavailable')
    name='archiveos-update-'+str(os.getpid())
    with tempfile.TemporaryDirectory(prefix='archiveos-minimize-') as directory:
        path=Path(directory)/'minimize.js';path.write_text(minimize_script(os.getpid()))
        reply=interface.call('loadScript',str(path),name)
        if reply.type()==QDBusMessage.MessageType.ErrorMessage or not reply.arguments() or int(reply.arguments()[0])<0:
            raise RuntimeError('Could not load KWin window control: '+reply.errorMessage())
        try:
            script=QDBusInterface('org.kde.KWin','/Scripting/Script'+str(reply.arguments()[0]),'org.kde.kwin.Script',bus)
            script.setTimeout(5000);result=script.call('run')
            if result.type()==QDBusMessage.MessageType.ErrorMessage:raise RuntimeError('Could not minimize windows: '+result.errorMessage())
        finally:interface.call('unloadScript',name)


def desktop_lock(app):
    from PyQt6.QtDBus import QDBusConnection,QDBusInterface,QDBusMessage
    bus=QDBusConnection.sessionBus()
    config=QSettings(str(Path.home()/'.config/kwinrulesrc'),QSettings.Format.IniFormat)
    rules=config.value('rules',[])
    if isinstance(rules,str):rules=[value.strip() for value in rules.split(',') if value.strip()]
    if not rules:rules=[str(i) for i in range(1,int(config.value('count',0))+1)]
    rule='archiveos-update-screen'
    config.setValue('rules',[rule,*[r for r in rules if r!=rule]])
    config.beginGroup(rule)
    geometry=app.primaryScreen().geometry()
    values={'Description':'ArchiveOS update screen','wmclass':'archiveos-update-screen','wmclassmatch':1,'wmclasscomplete':False,
        'fullscreen':True,'fullscreenrule':2,'above':True,'aboverule':2,'noborder':True,'noborderrule':2,
        'position':str(geometry.x())+','+str(geometry.y()),'positionrule':2,
        'size':str(geometry.width())+','+str(geometry.height()),'sizerule':2,
        'minimize':False,'minimizerule':2,'closeable':False,'closeablerule':2,
        'disableglobalshortcuts':True,'disableglobalshortcutsrule':2}
    for key,value in values.items():config.setValue(key,value)
    config.endGroup();config.sync()
    if config.status()!=QSettings.Status.NoError:raise RuntimeError('Cannot configure the update window')
    kwin=QDBusInterface('org.kde.KWin','/KWin','org.kde.KWin',bus)
    reply=kwin.call('reconfigure')
    if reply.type()==QDBusMessage.MessageType.ErrorMessage:raise RuntimeError(reply.errorMessage())
    block_shortcuts(True)


def block_shortcuts(blocked):
    from PyQt6.QtDBus import QDBusConnection,QDBusInterface,QDBusMessage
    interface=QDBusInterface('org.kde.kglobalaccel','/kglobalaccel','org.kde.KGlobalAccel',QDBusConnection.sessionBus())
    interface.setTimeout(3000)
    reply=interface.call('blockGlobalShortcuts',blocked)
    if reply.type()==QDBusMessage.MessageType.ErrorMessage:raise RuntimeError(reply.errorMessage())


class UpdateScreen(QWidget):
    def __init__(self,status,log,logo,lang='en',preview=False):
        super().__init__();self.words=TEXT[lang];self.status_path=status;self.log_path=log;self.offset=0;self.decoder=codecs.getincrementaldecoder('utf-8')(errors='replace');self.allow_close=preview;self.compact=False;self.log_identity=None
        if not preview:self.setWindowFlags(Qt.WindowType.FramelessWindowHint|Qt.WindowType.WindowStaysOnTopHint)
        self.setWindowTitle(self.words[0]);self.setWindowIcon(QIcon(str(logo)))
        self.setStyleSheet('''QWidget#updateScreen{background:#000000;color:#eeeeee}
        QLabel{background:transparent;color:#eeeeee}QLabel#subtitle,QLabel#phase{color:#aaaaaa;font-size:17px}
        QProgressBar{background:#202020;border:1px solid #444444;border-radius:8px;min-height:16px;max-height:16px}QProgressBar::chunk{background:#eeeeee;border-radius:7px}
        QPushButton{background:#171717;color:#eeeeee;border:1px solid #444444;border-radius:9px;padding:11px 22px;font-size:14px}QPushButton:hover{background:#303030}QPushButton:focus{border:2px solid #eeeeee}
        QPlainTextEdit{background:#101010;color:#eeeeee;border:1px solid #444444;border-radius:10px;padding:10px;font-family:monospace;font-size:12px}''')
        self.setObjectName('updateScreen');self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground,True);outer=QVBoxLayout(self);outer.setContentsMargins(36,28,36,24);outer.setSpacing(16)
        outer.addStretch(2);center=QWidget();self.center=center;center.setMaximumWidth(740);body=QVBoxLayout(center);self.outer=outer;body.setSpacing(22)
        mark=QLabel();self.brand=mark;pix=QPixmap(str(logo));self.logo_pixmap=pix;self.body=body
        if not pix.isNull():mark.setPixmap(pix.scaled(110,110,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        mark.setAlignment(Qt.AlignmentFlag.AlignCenter);body.addWidget(mark)
        self.title=QLabel(self.words[0]);self.title.setAlignment(Qt.AlignmentFlag.AlignCenter);self.title.setWordWrap(True);self.title.setStyleSheet('font-size:36px;font-weight:600');body.addWidget(self.title)
        self.subtitle=QLabel(self.words[1]);self.subtitle.setObjectName('subtitle');self.subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter);self.subtitle.setWordWrap(True);body.addWidget(self.subtitle)
        body.addSpacing(12);self.progress=QProgressBar();self.progress.setRange(0,100);self.progress.setValue(0);self.progress.setTextVisible(False);body.addWidget(self.progress)
        self.phase=QLabel(self.words[4]);self.phase.setObjectName('phase');self.phase.setAlignment(Qt.AlignmentFlag.AlignCenter);self.phase.setWordWrap(True);self.phase.setTextFormat(Qt.TextFormat.PlainText);self.phase.setSizePolicy(QSizePolicy.Policy.Preferred,QSizePolicy.Policy.Ignored);self.phase.setMinimumHeight(44);body.addWidget(self.phase)
        self.percent=QLabel('0%');self.percent.setAlignment(Qt.AlignmentFlag.AlignCenter);self.percent.setStyleSheet('font-size:18px;font-weight:600');body.addWidget(self.percent)
        outer.addWidget(center,0,Qt.AlignmentFlag.AlignHCenter);outer.addStretch(3)
        row=QHBoxLayout();row.addStretch();self.toggle=QPushButton(self.words[2]);self.toggle.clicked.connect(self.toggle_terminal);row.addWidget(self.toggle);row.addStretch();outer.addLayout(row)
        self.terminal=QPlainTextEdit();self.terminal.setReadOnly(True);self.terminal.setMaximumBlockCount(5000);self.terminal.setFixedHeight(230);self.terminal.hide();outer.addWidget(self.terminal)
        self.timer=QTimer(self);self.timer.timeout.connect(self.poll);self.timer.start(150);self.poll();self.fit_layout()
    def toggle_terminal(self):
        visible=self.terminal.isHidden();self.terminal.setVisible(visible);self.toggle.setText(self.words[3] if visible else self.words[2])
        self.fit_layout()
        if visible:self.read_log()
    def fit_layout(self):
        compact=not self.terminal.isHidden() or self.height()<700 or self.width()<800
        self.compact=compact
        self.center.setFixedWidth(max(240,min(740,self.width()-(32 if compact else 72))))
        size=42 if compact else 110
        if not self.logo_pixmap.isNull():self.brand.setPixmap(self.logo_pixmap.scaled(size,size,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        self.body.setSpacing(8 if compact else 22)
        self.outer.setSpacing(8 if compact else 16)
        self.outer.setContentsMargins(16 if compact else 36,12 if compact else 28,16 if compact else 36,12 if compact else 24)
        self.title.setStyleSheet('font-size:'+('24' if compact else '36')+'px;font-weight:600')
        self.subtitle.setStyleSheet('font-size:'+('14' if compact else '17')+'px')
        margins=self.body.contentsMargins()
        self.subtitle.setMinimumHeight(self.subtitle.heightForWidth(self.center.width()-margins.left()-margins.right()))
        self.terminal.setFixedHeight(max(80,min(230,self.height()//(6 if compact else 4))))
    def resizeEvent(self,event):
        super().resizeEvent(event)
        self.fit_layout()
    def read_log(self):
        try:
            with self.log_path.open('rb') as stream:
                info=os.fstat(stream.fileno());identity=(info.st_dev,info.st_ino)
                if identity!=self.log_identity:self.offset=0;self.decoder.reset();self.log_identity=identity
                end=stream.seek(0,2)
                if end<self.offset:self.offset=0;self.decoder.reset()
                if end-self.offset>524288:self.offset=end-524288;self.decoder.reset()
                stream.seek(self.offset);data=stream.read(65536);self.offset=stream.tell()
            if data:
                text=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',self.decoder.decode(data)).replace('\r','\n')
                scrollbar=self.terminal.verticalScrollBar();at_end=scrollbar.value()>=scrollbar.maximum()-2
                cursor=QTextCursor(self.terminal.document());cursor.movePosition(QTextCursor.MoveOperation.End);cursor.insertText(text)
                if at_end:scrollbar.setValue(scrollbar.maximum())
        except OSError:pass
    def poll(self):
        try:
            state=json.loads(self.status_path.read_text());value=max(0,min(100,int(state.get('percent',0))))
            self.progress.setValue(value);self.percent.setText(str(value)+'%');self.phase.setText(state.get('label',self.words[4]))
            if state.get('state')=='complete':self.title.setText(self.words[5]);self.subtitle.setText(self.words[6])
            elif state.get('state')=='failed':self.title.setText(self.words[7]);self.subtitle.setText(state.get('label',''))
            elif state.get('state')=='prompt':
                self.hide()
            elif state.get('state')=='close':
                self.allow_close=True;self.close()
        except (OSError,ValueError,TypeError):pass
        if not self.terminal.isHidden():self.read_log()
    def event(self,event):
        if not getattr(self,'allow_close',True) and event.type() in (QEvent.Type.ShortcutOverride,QEvent.Type.KeyPress) and event.key()==Qt.Key.Key_F4 and event.modifiers()&Qt.KeyboardModifier.AltModifier:
            event.accept();return True
        return super().event(event)
    def closeEvent(self,event):
        if self.allow_close:event.accept()
        else:event.ignore()

def main():
    p=argparse.ArgumentParser();p.add_argument('--status',type=Path,required=True);p.add_argument('--log',type=Path,required=True);p.add_argument('--logo',type=Path,required=True);p.add_argument('--lang',choices=TEXT,default='en');p.add_argument('--preview',type=Path);p.add_argument('--owner-pid',type=int);a=p.parse_args()
    app=QApplication(sys.argv[:1]);app.setApplicationName('archiveos-update-screen');app.setDesktopFileName('archiveos-update-screen');w=UpdateScreen(a.status,a.log,a.logo,a.lang,bool(a.preview))
    if a.preview:
        w.resize(1280,800);w.show();QTimer.singleShot(200,lambda:(w.grab().save(str(a.preview)),app.quit()))
    else:
        def ready():
            try:
                if app.platformName() not in ('offscreen','minimal'):minimize_other_windows()
                w.raise_();w.activateWindow()
                print('ARCHIVEOS_UI_READY',flush=True)
            except Exception as error:
                print(str(error),file=sys.stderr,flush=True);app.exit(1)
        locked=app.platformName() not in ('offscreen','minimal')
        if locked:
            desktop_lock(app)
            app.aboutToQuit.connect(lambda:block_shortcuts(False))
            guard=QTimer(app);guard.timeout.connect(lambda:block_shortcuts(True));guard.start(750)
        if a.owner_pid:
            def check_owner():
                if not Path('/proc',str(a.owner_pid)).exists():
                    import subprocess
                    w.allow_close=True;w.close()
                    subprocess.Popen(['systemctl','--user','start','plasma-plasmashell.service'])
                    app.quit()
            owner_timer=QTimer(app);owner_timer.timeout.connect(check_owner);owner_timer.start(1000)
        w.showFullScreen();QTimer.singleShot(350,ready)
    return app.exec()
if __name__=='__main__':sys.exit(main())
