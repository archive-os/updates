#!/usr/bin/env python3
"""Purge obsolete versioned Ubuntu kernels; keep newest per flavor and running ABI."""
import argparse, fcntl, functools, os, platform, re, subprocess
from pathlib import Path

IMAGE=re.compile(r'^linux-image-(?:unsigned-)?(\d+\.\d+\.\d+-\d+)-(.+)$')
VERSIONED=re.compile(r'^linux-(?:image(?:-unsigned)?|headers|modules(?:-extra)?|modules-nvidia-[a-zA-Z0-9-]+|objects-nvidia-[a-zA-Z0-9-]+|signatures-nvidia-[a-zA-Z0-9-]+|tools|cloud-tools|buildinfo)-')

def compare(a,b):
    for op,result in [('lt',-1),('gt',1)]:
        if subprocess.run(['dpkg','--compare-versions',a,op,b]).returncode==0:return result
    return 0

def candidates(packages,running,root=Path('/')):
    images={}
    for name,status in packages:
        m=IMAGE.fullmatch(name)
        if m and status=='installed':
            abi=m[1]+'-'+m[2];images.setdefault(m[2],set()).add(abi)
    abi_base=lambda abi:re.match(r'^\d+\.\d+\.\d+-\d+',abi)[0]
    keep={running};old=set();old_bases=set();keep_bases={abi_base(running)}
    for flavor,abis in images.items():
        newest=max(abis,key=functools.cmp_to_key(compare))
        # Refuse deleting an old kernel until its replacement has boot artifacts.
        if not all((root/p).is_file() for p in ('boot/vmlinuz-'+newest,'boot/initrd.img-'+newest)):
            keep.update(abis);continue
        keep.add(newest);old.update(abis-{newest,running})
    keep_bases.update(abi_base(abi) for abi in keep)
    old_bases.update(abi_base(abi) for abi in old)
    selected=[]
    for name,status in packages:
        if status not in ('installed','config-files') or not VERSIONED.match(name):continue
        if any(name.endswith('-'+abi) for abi in keep):continue
        m=IMAGE.fullmatch(name)
        if m and status=='config-files':
            abi=m[1]+'-'+m[2]
            if abi not in keep and m[2] in images:old.add(abi);old_bases.add(m[1])
        if any(name.endswith('-'+abi) for abi in old) or any(name.endswith('-'+base) for base in old_bases-keep_bases):selected.append(name)
    return sorted(selected)

def guard(plan,selected):
    removed=set(re.findall(r'^(?:Remv|Purg) ([^\s:]+)',plan,re.M))
    extra=removed-set(selected)
    if extra:raise RuntimeError('Refusing dependent package removal: '+', '.join(sorted(extra)))
    if re.search(r'^Inst ',plan,re.M):raise RuntimeError('Unexpected installation in kernel purge plan')
    if not removed:raise RuntimeError('APT did not confirm the kernel removal plan')

def main():
    p=argparse.ArgumentParser();p.add_argument('--apply',action='store_true');args=p.parse_args()
    if args.apply and os.geteuid()!=0:raise RuntimeError('Root required')
    lock=None
    if args.apply:
        lock=Path('/run/lock/archiveos-kernel-cleanup.lock').open('w')
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:return
    output=subprocess.check_output(['dpkg-query','-W','-f=${Package}\t${db:Status-Status}\n','linux-*'],text=True)
    packages=[tuple(line.split('\t')) for line in output.splitlines() if '\t' in line]
    selected=candidates(packages,platform.release())
    print('Running kernel retained: '+platform.release(),flush=True)
    if not selected:print('No obsolete kernel packages to remove.',flush=True);return
    print('Obsolete kernel packages: '+', '.join(selected),flush=True)
    env={**os.environ,'LC_ALL':'C','DEBIAN_FRONTEND':'noninteractive'}
    result=subprocess.run(['apt-get','-s','purge',*selected],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    print(result.stdout,flush=True)
    if result.returncode:raise RuntimeError('APT kernel purge simulation failed')
    guard(result.stdout,selected)
    if args.apply:
        subprocess.run(['apt-get','-y','purge',*selected],env=env,check=True)
        subprocess.run(['update-grub'],check=True)

if __name__=='__main__':main()
