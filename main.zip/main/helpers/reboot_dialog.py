#!/usr/bin/env python3
"""Return 10 for reboot, 0 for later. Never reboot from the GUI itself."""
import argparse, sys
from pathlib import Path
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QIcon, QPixmap
from PyQt6.QtWidgets import QApplication, QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton

TEXT={
 'tr':('Güncelleme tamamlandı','ArchiveOS hazır.','Değişikliklerin ve yeni panel düzeninin uygulanması için yeniden başlatılsın mı?','Daha sonra','Yeniden başlat'),
 'en':('Update complete','ArchiveOS is ready.','Restart now to apply the changes and the new panel layout?','Later','Restart now')}
class Dialog(QDialog):
    def __init__(self,lang):
        super().__init__();t=TEXT[lang];self.setWindowTitle('ArchiveOS · '+t[0]);self.setMinimumWidth(480)
        self.setStyleSheet('QDialog{background:#f6f8fc;color:#172540}QLabel{color:#172540}QPushButton{background:#fff;color:#172540;border:1px solid #dce5ed;border-radius:9px;padding:12px 22px;min-height:20px;font-size:14px}QPushButton:hover{background:#eaf6fd}QPushButton#restart{background:#a9ddf7;border-color:#a9ddf7}QPushButton:focus{border:2px solid #319bcf}')
        layout=QVBoxLayout(self);layout.setContentsMargins(32,30,32,30);layout.setSpacing(18)
        brand=QHBoxLayout();logo=QLabel();path='/usr/share/icons/Aos/aos-menu.png'
        if Path(path).exists():logo.setPixmap(QPixmap(path).scaled(48,48,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation));self.setWindowIcon(QIcon(path));brand.addWidget(logo)
        name=QLabel('ArchiveOS');name.setStyleSheet('font-size:23px;font-weight:600');brand.addWidget(name);brand.addStretch();layout.addLayout(brand)
        title=QLabel(t[1]);title.setStyleSheet('font-size:22px;font-weight:600');layout.addWidget(title)
        desc=QLabel(t[2]);desc.setWordWrap(True);desc.setMaximumWidth(440);desc.setStyleSheet('font-size:14px;color:#617185');layout.addWidget(desc)
        actions=QHBoxLayout();later=QPushButton(t[3]);later.setDefault(True);later.clicked.connect(lambda:self.done(0));restart=QPushButton(t[4]);restart.setObjectName('restart');restart.clicked.connect(lambda:self.done(10));actions.addStretch();actions.addWidget(later);actions.addWidget(restart);layout.addLayout(actions)
        self.result_code=0
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--lang',choices=TEXT,default='tr');p.add_argument('--preview',type=Path);a=p.parse_args()
    app=QApplication(sys.argv[:1]);d=Dialog(a.lang)
    if a.preview:
        d.show();QTimer.singleShot(150,lambda:(d.grab().save(str(a.preview)),app.exit(0)));sys.exit(app.exec())
    sys.exit(d.exec())
