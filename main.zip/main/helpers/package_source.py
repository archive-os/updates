"""ArchiveOS GitHub catalog, immutable metadata and installed-only updates."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tempfile
from urllib.parse import quote, urlsplit
from urllib.request import Request, urlopen, HTTPRedirectHandler, build_opener
from urllib.error import HTTPError
import xml.etree.ElementTree as ET

BASE = Path(__file__).resolve().parent
CONFIG = BASE / 'sources.json'
HOSTS = {'github.com', 'api.github.com', 'raw.githubusercontent.com',
         'release-assets.githubusercontent.com', 'objects.githubusercontent.com'}
PKG = re.compile(r'(?:aos-[a-z0-9][a-z0-9+.-]*|archiveos-[a-z0-9][a-z0-9+.-]*|aosver|archive-store)\Z')

def safe_url(url):
    p=urlsplit(url)
    if p.scheme!='https' or p.hostname not in HOSTS or p.username or p.password or p.port not in (None,443):
        raise ValueError('Invalid ArchiveOS download URL')
    return url

class Redirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        safe_url(newurl)
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def fetch(url, limit=4*1024*1024, destination=None):
    accept='application/vnd.github+json' if urlsplit(url).hostname=='api.github.com' else 'application/octet-stream'
    request=Request(safe_url(url),headers={'User-Agent':'ArchiveStore','Accept':accept})
    with build_opener(Redirect()).open(request,timeout=45) as response:
        safe_url(response.url)
        if destination is None:
            data=response.read(limit+1)
            if len(data)>limit:raise ValueError('ArchiveOS metadata is too large')
            return data
        count=0;digest=hashlib.sha256()
        with Path(destination).open('wb') as stream:
            while block:=response.read(1024*1024):
                count+=len(block)
                if count>limit:raise ValueError('ArchiveOS package is too large')
                digest.update(block);stream.write(block)
        return count,digest.hexdigest()

def configuration(path=None):
    data=json.loads(Path(path or CONFIG).read_text())['archiveos']
    if not data.get('enabled'):return None
    repo=data.get('repository','')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9-]*/aos-packages',repo):raise ValueError('Invalid ArchiveOS repository')
    return repo

def valid_version(version):
    if not isinstance(version,str) or not version or len(version)>100 or version.startswith('-'):
        raise ValueError('Invalid Debian version')
    if subprocess.run(['/usr/bin/dpkg','--validate-version',version],capture_output=True).returncode:
        raise ValueError('Invalid Debian version')
    return version

def newer(candidate, installed):
    valid_version(candidate);valid_version(installed)
    return subprocess.run(['/usr/bin/dpkg','--compare-versions',candidate,'gt',installed]).returncode==0

def installed_versions():
    result=subprocess.run(['/usr/bin/dpkg-query','-W','-f=${Package}\t${Version}\t${db:Status-Status}\n'],
                          check=True,text=True,stdout=subprocess.PIPE)
    return {parts[0]:parts[1] for line in result.stdout.splitlines()
            if len(parts:=line.split('\t'))==3 and parts[2]=='installed'}

def revision(repo):
    try:
        commit=json.loads(fetch(f'https://api.github.com/repos/{repo}/commits/main'))['sha']
    except HTTPError as error:
        if error.code not in (403,429):raise
        raw=fetch(f'https://github.com/{repo}/commits/main.atom')
        if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():raise ValueError('Invalid catalog feed')
        identifier=ET.fromstring(raw).findtext('{http://www.w3.org/2005/Atom}entry/{http://www.w3.org/2005/Atom}id','')
        match=re.fullmatch(r'tag:github.com,2008:Grit::Commit/([0-9a-f]{40})',identifier)
        if not match:raise ValueError('Invalid catalog revision')
        commit=match[1]
    if not isinstance(commit,str) or not re.fullmatch('[0-9a-f]{40}',commit):raise ValueError('Invalid catalog revision')
    return commit

def media_path(path, prefix, repo, commit, base_path=''):
    if not isinstance(path,str):raise ValueError('Invalid media path')
    value=PurePosixPath(path)
    if value.is_absolute() or '..' in value.parts or not path.startswith(prefix+'/') or '\\' in path:
        raise ValueError('Invalid media path')
    return f'https://raw.githubusercontent.com/{repo}/{commit}/'+(base_path+'/' if base_path else '')+quote(path,safe='/')

def localized_title(item,desktop):
    import configparser
    title=str(item.get('name',item['package']))[:200]
    translated=item.get('name_tr','')
    path=Path('/usr/share/applications')/desktop
    if path.is_file():
        cfg=configparser.ConfigParser(interpolation=None,strict=False);cfg.optionxform=str
        try:
            cfg.read(path,encoding='utf-8')
            translated=cfg.get('Desktop Entry','Name[tr]',fallback='') or translated
        except (OSError,UnicodeError,configparser.Error):pass
    fallback={'aos-welcome':'ArchiveOS’a Hoş Geldiniz','aos-touch-keyboard':'ArchiveOS Dokunmatik Klavye','aos-gaming-center':'ArchiveOS Oyun Merkezi','aos-windows-app-support':'ArchiveOS Windows Uygulama Desteği','aosver':'ArchiveOS Hakkında','aos-pomodoro':'ArchiveOS Pomodoro','aos-terminal':'ArchiveOS Terminal'}
    return title,str(translated or fallback.get(item['package'],title))[:200]


def catalog(config=None):
    repo=configuration(config)
    if not repo:return []
    commit=revision(repo);root=f'https://raw.githubusercontent.com/{repo}/{commit}'
    path=json.loads(Path(config or CONFIG).read_text())['archiveos'].get('path','')
    if path not in ('','packages'):raise ValueError('Invalid catalog directory')
    base=root+('/'+path if path else '')
    try:data=json.loads(fetch(base+'/packages.json'))
    except HTTPError as error:
        if error.code!=404 or not path:raise
        path='';base=root;data=json.loads(fetch(base+'/packages.json'))
    logos=json.loads(fetch(base+'/logos.json'))
    shots=json.loads(fetch(base+'/screenshots.json'))
    if any(d.get('schema_version')!=1 for d in (data,logos,shots)):raise ValueError('Unsupported catalog schema')
    packages=data.get('packages');tag=data.get('release_tag','')
    if not isinstance(packages,list) or len(packages)>256 or not re.fullmatch('[A-Za-z0-9._-]{1,100}',tag):
        raise ValueError('Invalid ArchiveOS catalog')
    architecture=subprocess.check_output(['/usr/bin/dpkg','--print-architecture'],text=True).strip()
    installed=installed_versions();result=[];seen=set()
    for item in packages:
        name=item.get('package','');version=valid_version(item.get('version'))
        if not PKG.fullmatch(name) or name in seen:raise ValueError('Invalid or duplicate ArchiveOS package')
        seen.add(name)
        asset=item.get('asset','')
        if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_.+~:-]*\.deb',asset):raise ValueError('Invalid DEB asset')
        url=f'https://github.com/{repo}/releases/download/{quote(tag,safe="")}/{quote(asset,safe="")}'
        relative=(path+'/' if path else '')+'release-assets/'+quote(asset,safe='')
        raw=f'https://raw.githubusercontent.com/{repo}/{commit}/'+relative
        branch_url=f'https://raw.githubusercontent.com/{repo}/main/'+relative
        legacy_raw=f'https://raw.githubusercontent.com/{repo}/{commit}/release-assets/{quote(asset,safe="")}'
        legacy_branch=f'https://raw.githubusercontent.com/{repo}/main/release-assets/{quote(asset,safe="")}'
        declared=item.get('deb_url')
        if declared is None or declared in (raw,branch_url,legacy_raw,legacy_branch):
            url=raw
        elif declared!=url:
            raise ValueError('Catalog DEB URL does not match the repository')
        if not re.fullmatch('[0-9a-f]{64}',item.get('sha256','')):raise ValueError('Invalid package SHA256')
        if type(item.get('size')) is not int or not 0<item['size']<=1024*1024*1024:raise ValueError('Invalid package size')
        if item.get('architecture') not in ('all',architecture):continue
        logo=media_path(logos['logos'][name],'logos',repo,commit,path)
        images=shots['screenshots'][name]
        if not isinstance(images,list) or len(images)>6:raise ValueError('Invalid screenshots')
        images=[media_path(p,'screenshots/'+name,repo,commit,path) for p in images]
        title=str(item.get('name',name))[:200];summary=item.get('summary',{})
        category={'System':'system','Utility':'utilities','Office':'office','Game':'games','Accessibility':'accessibility'}.get(item.get('category'),'other')
        desktop=str(item.get('desktop_id',''))
        if not re.fullmatch(r'[A-Za-z0-9_.+-]+\.desktop',desktop):raise ValueError('Invalid desktop ID')
        title,localized=localized_title(item,desktop)
        current=installed.get(name,'')
        result.append(dict(item,deb_url=url,backend='archiveos',github=True,source='GitHub · '+repo,
                           name=title,tr=localized,summary=summary.get('en',''),summary_tr=summary.get('tr',''),
                           description=str(item.get('description',''))[:20000],category=category,
                           installed=current,upgradable=bool(current and newer(version,current)),
                           available=True,protected=name not in ('aos-pomodoro','aos-touch-keyboard'),installed_size=0,icon=name,logo_url=logo,
                           screenshots=images,appstream_id=desktop,desktop='/usr/share/applications/'+desktop,
                           origin=repo,commit=commit))
    return result

def scan():
    rows=catalog();warnings=[]
    for row in rows:
        try:row['_logo_bytes']=fetch(row['logo_url'],2*1024*1024)
        except (OSError,ValueError) as error:warnings.append(row['package']+': '+str(error))
    return rows,warnings

def install(names=None, installed_only=True, config=None, run=None):
    if os.geteuid()!=0:raise PermissionError('ArchiveOS package updates require administrator authorization')
    repo=configuration(config)
    if not repo:
        if names:raise ValueError('ArchiveOS package repository is not configured')
        print('ArchiveOS package repository is not configured; online packages skipped.',flush=True)
        return []
    if names is not None and (not isinstance(names,list) or not names or any(not isinstance(n,str) or not PKG.fullmatch(n) for n in names)):
        raise ValueError('Invalid ArchiveOS package selection')
    rows=catalog(config);by_name={a['package']:a for a in rows}
    if names and set(names)-set(by_name):raise ValueError('Selected package is not in the trusted catalog')
    rows=[a for a in rows if (names is None or a['package'] in names)]
    current=installed_versions()
    rows=[a for a in rows if (a['package'] in current and newer(a['version'],current[a['package']])) or
          (not installed_only and a['package'] not in current)]
    if not rows:
        print('Installed ArchiveOS packages are up to date.',flush=True);return []
    def execute(argv,capture=False):
        if run:return run(argv,capture=capture)
        return subprocess.run(argv,check=True,text=True,stdout=subprocess.PIPE if capture else None)
    with tempfile.TemporaryDirectory(prefix='archiveos-packages-') as tmp:
        files=[]
        for row in rows:
            file=Path(tmp)/row['asset'];print('ArchiveOS: '+row['package']+' '+row['version'],flush=True)
            size,digest=fetch(row['deb_url'],row['size'],file)
            if size!=row['size'] or digest!=row['sha256']:raise ValueError('Downloaded DEB checksum mismatch')
            for key,field in [('package','Package'),('version','Version'),('architecture','Architecture')]:
                actual=subprocess.check_output(['/usr/bin/dpkg-deb','-f',str(file),field],text=True).strip()
                if actual!=row[key]:raise ValueError('Downloaded DEB metadata mismatch')
            files.append(str(file))
        current=installed_versions()
        if any((installed_only and a['package'] not in current) or
               (a['package'] in current and not newer(a['version'],current[a['package']])) for a in rows):
            raise ValueError('Installed package versions changed; check again')
        plan=execute(['/usr/bin/apt-get','--simulate','install',*files],capture=True).stdout
        if re.search(r'^(?:Remv|Purg) ',plan,re.M):raise ValueError('ArchiveOS updates would remove packages')
        execute(['/usr/bin/apt-get','-y','--no-remove','-o','Dpkg::Options::=--force-confdef',
                 '-o','Dpkg::Options::=--force-confold','install',*files])
        actual=installed_versions()
        if any(actual.get(a['package'])!=a['version'] for a in rows):raise RuntimeError('ArchiveOS package installation was not completed')
    return [a['package'] for a in rows]
