#!/usr/bin/env python3
import argparse, codecs, errno, pty, select, time, datetime, fcntl, hashlib, json, os, pwd, re, shlex, shutil, stat, subprocess, sys, tarfile, tempfile
from pathlib import Path, PurePosixPath
from urllib.parse import urlsplit

TEXT={
 'tr':{'snapshot':'Timeshift yedeği alınıyor…','repo':'Ubuntu depoları hazırlanıyor…','upgrade':'Ubuntu paketleri güncelleniyor…','apps':'ArchiveOS uygulamaları kuruluyor…','branding':'ArchiveOS temaları ve kimliği uygulanıyor…','boot':'Açılış görüntüsü yeniden oluşturuluyor…','complete':'Güncelleme tamamlandı.','error':'Güncelleme durduruldu','reboot':'Şimdi yeniden başlatılsın mı? [e/H]: ','failed_backup':'Timeshift yedeği doğrulanamadı; sistem güncellenmedi.'},
 'en':{'snapshot':'Creating Timeshift snapshot…','repo':'Preparing Ubuntu sources…','upgrade':'Upgrading Ubuntu packages…','apps':'Installing ArchiveOS applications…','branding':'Applying ArchiveOS themes and identity…','boot':'Rebuilding boot images…','complete':'Update complete.','error':'Update stopped','reboot':'Restart now? [y/N]: ','failed_backup':'Timeshift snapshot could not be verified; system was not updated.'}}
ALLOWED=('etc/sddm.conf.d/zzzz-archiveos-theme.conf','etc/X11/Xsession.d/70archiveos-defaults','etc/os-release','usr/lib/os-release','etc/lsb-release','etc/issue','etc/issue.net','etc/ArchiveOS-Logo.txt','etc/fastfetch','etc/sddm.conf','etc/xdg','etc/skel/.config','etc/skel/.face','etc/skel/.face.icon','etc/apt/apt.conf.d/20archive','etc/bash.bashrc.d/50-archiveos-fastfetch.sh','etc/plymouth','etc/default/grub.d/zzzz-archiveos-branding.cfg','etc/initramfs-tools/hooks/zz-archiveos-branding','usr/share/plasma','usr/share/icons','usr/share/wallpapers/ArchiveOS','usr/share/sddm/themes/ArchiveOS','usr/share/sddm/themes/ArchiveOS-Dark','usr/share/plymouth/themes/ArchiveOS','usr/share/pixmaps','usr/local/libexec','usr/share/archiveos-default-settings')
THEME_DIRS=('plasma/look-and-feel','plasma/desktoptheme','plasma/layout-templates',
            'sddm/themes','plymouth/themes','wallpapers','backgrounds','color-schemes','themes','aurorae/themes','konsole')
DESKTOP_LINKS=('calamares.desktop','calamares-launch-oem.desktop','kubuntu-calamares.desktop','org.kubuntu.web.home.desktop','org.kubuntu.restore-desktop-links.desktop','org.kfocus.web.howtos.desktop','org.kubuntu.manage-software.desktop')
PLYMOUTH_REMOVE={'details','text','tribar','breeze','breeze-text','bgrt','spinner'}
FASTFETCH_SOURCE='[ ! -r /etc/bash.bashrc.d/50-archiveos-fastfetch.sh ] || . /etc/bash.bashrc.d/50-archiveos-fastfetch.sh'
SPLASH_ID='org.archiveos.desktop'
LEGACY_SPLASH_ID='org.archiveos.splash.desktop'

def shared_splash_config(text):
    return re.sub(r'(?m)^(Theme[ \t]*=[ \t]*)org\.archiveos(?:-dark|\.splash)?\.desktop[ \t]*$',r'\g<1>'+SPLASH_ID,text)

def normalize_fastfetch(text,system=False):
    lines=[]
    for line in text.splitlines():
        if line.strip() in ('fastfetch','command fastfetch',FASTFETCH_SOURCE):
            if not system:lines.append(FASTFETCH_SOURCE)
        elif line.strip()!='# ArchiveOS interactive shell branding':lines.append(line)
    result='\n'.join(lines)+'\n'
    if system:result=result.rstrip()+'\n\n# ArchiveOS interactive shell branding\n'+FASTFETCH_SOURCE+'\n'
    return result

def read_os(root=Path('/')):
    text=(root/'etc/os-release').read_text()
    return dict(re.findall(r'^([A-Z_]+)=["\']?([^\n"\']*)',text,re.M))

def safe_rel(name):
    p=PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or not p.parts or str(p)=='.':raise ValueError('Unsafe path: '+name)
    return str(p)

def verify(bundle,manifest):
    for rel,digest in manifest['files'].items():
        p=bundle/safe_rel(rel)
        if p.is_symlink() or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:
            raise ValueError('Checksum mismatch: '+rel)
    for package in manifest['packages']:
        name=package['file']
        if Path(safe_rel(name)).name!=name or ('programs/'+name) not in manifest['files']:raise ValueError('Invalid DEB path')
    for rel in manifest['source_roots']:
        safe_rel(rel)
        if not any(rel==r or rel.startswith(r+'/') for r in ALLOWED):raise ValueError('Unsafe replacement root')
    for rel in manifest['cleanup']:
        safe_rel(rel)
        if rel not in {'etc/calamares','etc/xdg/calamaresrc','usr/share/archiveos-default-settings/calamaresrc'} | {'usr/share/applications/'+name for name in DESKTOP_LINKS} and not rel.startswith(('usr/share/wallpapers/Kubuntu','usr/share/sddm/themes/ubuntu','usr/share/sddm/themes/kubuntu','usr/share/plasma/look-and-feel/org.kubuntu','usr/share/icons/ubuntu-mono-','usr/share/kubuntu-default-settings','etc/kubuntu-default-settings','etc/sddm.conf.d/20-kubuntu.conf','etc/sddm.conf.d/kubuntu_settings.conf','etc/X11/Xsession.d/70xdg-kubuntu-dir')):raise ValueError('Unsafe cleanup target')
    for item in manifest.get('services',[]):
        if item['target'] not in ('etc/systemd/user/aos-update-checker.service','etc/xdg/autostart/aos-update-checker.desktop') or item['file'] not in manifest['files']:
            raise ValueError('Invalid service payload')
    validate_overlay(bundle/'archiveos-overlay.tar.gz')

def validate_overlay(archive):
    with tarfile.open(archive,'r:gz') as tar:
        names=set()
        members=tar.getmembers()
        lookup={m.name:m for m in members}
        for m in members:
            rel=safe_rel(m.name)
            if rel in names:raise ValueError('Duplicate archive path: '+rel)
            names.add(rel)
            if not any(rel==r or rel.startswith(r+'/') or (m.isdir() and r.startswith(rel+'/')) for r in ALLOWED):raise ValueError('Unexpected overlay path: '+rel)
            if not (m.isdir() or m.isfile() or m.issym()):raise ValueError('Unsupported archive entry: '+rel)
            if m.issym():
                # Links may point at another system theme, never outside /usr/share.
                target=os.path.normpath(os.path.join('/'+str(PurePosixPath(rel).parent),m.linkname))
                if not (target.startswith('/usr/share/') or (rel=='etc/skel/.face.icon' and target=='/etc/skel/.face')):raise ValueError('Unsafe link: '+rel)
        for name in names:
            parts=PurePosixPath(name).parts
            for n in range(1,len(parts)):
                parent='/'.join(parts[:n]);m=lookup.get(parent)
                if m and m.issym():raise ValueError('Archive writes through a symlink')

def ubuntu_uri(uri):
    host=urlsplit(uri).hostname or ''
    return host in ('archive.ubuntu.com','security.ubuntu.com','ports.ubuntu.com') or host.endswith('.archive.ubuntu.com')

def filter_sources(text,suffix):
    if suffix=='.sources':
        keep=[]
        for stanza in re.split(r'\n\s*\n',text.strip()):
            uris=re.search(r'^URIs:\s*(.*)$',stanza,re.M)
            if not uris:keep.append(stanza);continue
            flags=[ubuntu_uri(u) for u in uris.group(1).split()]
            if any(flags) and not all(flags):raise ValueError('Mixed official/third-party URI stanza; split it first')
            if not any(flags):keep.append(stanza)
        return '\n\n'.join(keep)+'\n' if keep else ''
    lines=[]
    for line in text.splitlines():
        if line.lstrip().startswith(('deb ','deb-src ')) and any(ubuntu_uri(t) for t in line.split() if '://' in t):continue
        lines.append(line)
    return '\n'.join(lines)+'\n'

PROTECTED={'base-files','libc6','python3','python3-minimal','systemd','systemd-sysv','dbus','sddm','plasma-desktop','plasma-workspace','plasma-session-wayland','kwin-wayland','timeshift','ubuntu-minimal','apt','dpkg','initramfs-tools'}
def guard_upgrade_plan(plan):
    removed=re.findall(r'^(?:Remv|Purg) ([^\s:]+)',plan,re.M)
    blocked=[p for p in removed if p in PROTECTED or p.startswith(('linux-image-','grub-','shim-'))]
    if blocked:raise RuntimeError('APT would remove required desktop/boot packages: '+', '.join(blocked))


class Progress:
    """Phase progress, not a prediction of remaining time."""
    def __init__(self,lang='en',log=None):
        self.lang=lang;self.log=log;self.percent=0;self.label='';self.tick=0;self.last=0
        self.tty=sys.stdout.isatty();self.visible=False
    def clear(self):
        if self.visible:
            print('\r\033[2K',end='',flush=True);self.visible=False
    def message(self,text):
        self.clear();print(text,flush=True)
        if self.log:
            with self.log.open('a') as out:out.write(text+'\n')
    def stage(self,percent,label):
        self.percent=percent;self.label=label;self.render(force=True)
    def render(self,force=False):
        now=time.monotonic()
        if not force and now-self.last < (1 if self.tty else 10):return
        self.last=now;self.tick+=1;self.clear()
        width=20;done=int(width*self.percent/100)
        title='Aşama ilerlemesi' if self.lang=='tr' else 'Stage progress'
        mark='✓' if self.percent==100 else '|/-\\'[self.tick%4]
        line=f'{title}: [{"#"*done}{"-"*(width-done)}] {self.percent:3d}% {mark} {self.label}'
        print(line,end='\r' if self.tty and not force else '\n',flush=True)
        self.visible=self.tty and not force
        if force and self.log:
            with self.log.open('a') as out:out.write(line+'\n')


class Runner:
    def __init__(self,log,progress=None):self.log=log;self.progress=progress or Progress(log=log)
    def __call__(self,args,capture=False,check=True,env=None):
        self.progress.message('+ '+shlex.join(map(str,args)))
        # A terminal output descriptor keeps Timeshift/dpkg output responsive.
        # stdin remains unchanged; unattended package configuration is preserved.
        master,slave=pty.openpty()
        decoder=codecs.getincrementaldecoder('utf-8')(errors='replace');chunks=[]
        proc=None
        try:
            proc=subprocess.Popen(args,stdout=slave,stderr=slave,env=env,close_fds=True)
            os.close(slave);slave=None
            with self.log.open('a') as out:
                while True:
                    ready,_,_=select.select([master],[],[],0.2)
                    if ready:
                        try:data=os.read(master,65536)
                        except OSError as e:
                            if e.errno!=errno.EIO:raise
                            data=b''
                        if not data:break
                        text=decoder.decode(data)
                        self.progress.clear();print(text,end='',flush=True);out.write(text);out.flush()
                        if capture:chunks.append(text)
                    else:self.progress.render()
                tail=decoder.decode(b'',final=True)
                if tail:
                    self.progress.clear();print(tail,end='',flush=True);out.write(tail)
                    if capture:chunks.append(tail)
            code=proc.wait()
        finally:
            os.close(master)
            if slave is not None:os.close(slave)
            if proc is not None and proc.poll() is None:
                proc.terminate();proc.wait()
            self.progress.clear()
        # Match subprocess text mode for callers parsing captured command output.
        result=subprocess.CompletedProcess(args,code,''.join(chunks).replace('\r\n','\n') if capture else '')
        if check and result.returncode:raise RuntimeError('Command failed: '+shlex.join(map(str,args)))
        return result

class Updater:
    def __init__(self,bundle,manifest,root,backup,run,lang):
        self.bundle=bundle;self.m=manifest;self.root=root;self.backup=backup;self.run=run;self.lang=lang;self.t=TEXT[lang];self.progress=getattr(run,'progress',None) or Progress(lang)
    def detail(self,tr,en,rel):
        self.progress.message((tr if self.lang=='tr' else en)+': '+rel)
    def target(self,rel):
        p=self.root/safe_rel(rel)
        for parent in p.parents:
            if parent==self.root:break
            if parent.is_symlink():raise ValueError('Destination parent is a symlink: '+str(parent))
        return p
    def save(self,rel,move=False):
        p=self.target(rel)
        if not p.exists() and not p.is_symlink():return
        self.detail('Yedekleniyor / kaldırılıyor' if move else 'Yedekleniyor','Backing up / removing' if move else 'Backing up',rel)
        saved=self.backup/'files'/rel;saved.parent.mkdir(parents=True,exist_ok=True)
        if not saved.exists() and not saved.is_symlink():
            if move:shutil.move(str(p),str(saved));return
            if p.is_symlink():saved.symlink_to(os.readlink(p))
            elif p.is_dir():shutil.copytree(p,saved,symlinks=True)
            else:shutil.copy2(p,saved)
        if move:
            if p.is_dir() and not p.is_symlink():shutil.rmtree(p)
            else:p.unlink()
    def write(self,rel,data,mode=0o644,save_existing=True):
        p=self.target(rel)
        if save_existing:self.save(rel)
        p.parent.mkdir(parents=True,exist_ok=True)
        temp=p.with_name(p.name+'.archiveos-new')
        # Never open an existing symbolic link, even for a temporary filename.
        temp.unlink(missing_ok=True);temp.write_bytes(data);temp.chmod(mode);os.replace(temp,p)
        self.detail('Dosya uygulanıyor','Applying file',rel)
    def cleanup_branding(self):
        """Discover vendor assets after APT; never traverse directory symlinks."""
        def scan(rel,match,recursive=True):
            base=self.target(rel)
            if not base.is_dir() or base.is_symlink():return
            for directory,dirs,files in os.walk(base,followlinks=False):
                for name in list(dirs)+files:
                    p=Path(directory)/name
                    if match(name):
                        self.save(p.relative_to(self.root).as_posix(),move=True)
                        if name in dirs:dirs.remove(name)
                    elif name in dirs and p.is_symlink():dirs.remove(name)
                if not recursive:dirs.clear()
        branded=lambda name:'ubuntu' in name.casefold()
        shares=['usr/share','usr/local/share']
        homes=['etc/skel','root']+[u.pw_dir.lstrip('/') for u in pwd.getpwall()
               if 1000<=u.pw_uid<60000 and u.pw_dir.startswith('/home/')]
        for home in dict.fromkeys(homes):
            self.save(home+'/.config/calamaresrc',move=True)
            p=self.target(home)
            if not p.is_dir() or p.is_symlink():continue
            shares.append(home+'/.local/share')
            for folder in ('.themes','.icons'):scan(home+'/'+folder,branded,recursive=folder=='.themes')
            desktops={'Desktop','Masaüstü'}
            config=p/'.config/user-dirs.dirs'
            if config.is_file() and not config.is_symlink():
                found=re.search(r'^XDG_DESKTOP_DIR="([^"\n]+)"',config.read_text(),re.M)
                if found:
                    value=found.group(1).replace('$HOME','/'+home)
                    try:desktops.add(PurePosixPath(value).relative_to('/'+home).as_posix())
                    except ValueError:pass
            for folder in desktops:
                if folder!='.':scan(home+'/'+safe_rel(folder),lambda name:name in DESKTOP_LINKS)
            scan(home+'/.config/autostart',lambda name:name in DESKTOP_LINKS)
        for share in shares:
            for folder in THEME_DIRS:scan(share+'/'+folder,branded)
            # An icon theme is the top-level package, not an application icon inside it.
            scan(share+'/icons',branded,recursive=False)
            scan(share+'/applications',lambda name:name in DESKTOP_LINKS)
        import configparser
        for home in homes:
            rel=home+'/.config/kcm-about-distrorc'
            p=self.target(rel)
            if p.is_file() and not p.is_symlink():
                cfg=configparser.ConfigParser(interpolation=None,strict=False);cfg.read(p)
                if cfg.get('General','Name',fallback='').strip().lower() in ('ubuntu','kubuntu'):
                    self.save(rel,move=True)
        scan('etc/sddm.conf.d',branded)
        for rel in self.m['cleanup']:self.save(rel,move=True)

    def snapshot(self):
        self.progress.stage(0,self.t['snapshot'])
        # O is the default; explicitly passing it is rejected by some Timeshift builds.
        env={**os.environ,'LC_ALL':'C'}
        before=self.run(['timeshift','--list','--scripted'],capture=True,env=env).stdout
        self.run(['timeshift','--create','--comments','ArchiveOS pre-update '+self.backup.name,'--scripted'],env=env)
        after=self.run(['timeshift','--list','--scripted'],capture=True,env=env).stdout
        pattern=r'\b\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}\b'
        created=set(re.findall(pattern,after))-set(re.findall(pattern,before))
        if not created:raise RuntimeError(self.t['failed_backup'])
        (self.backup/'timeshift-snapshot.txt').write_text('\n'.join(sorted(created))+'\n')
    def repos(self):
        if not (self.backup/'timeshift-snapshot.txt').is_file():raise RuntimeError(self.t['failed_backup'])
        self.progress.stage(10,self.t['repo'])
        apt=self.root/'etc/apt'
        paths=[apt/'sources.list',*(apt/'sources.list.d').glob('*.list'),*(apt/'sources.list.d').glob('*.sources')]
        # The user requested the ISO repository set, not a mixture with old target sources.
        for p in paths:
            rel=p.relative_to(self.root).as_posix()
            p=self.target(rel)
            if p.exists() or p.is_symlink():
                p.unlink();self.detail('Eski depo kaldırılıyor','Removing old repository',rel)
        for p in sorted((self.bundle/'apt').iterdir()):
            if p.name=='ubuntu-archive-keyring.gpg':
                self.write('usr/share/keyrings/'+p.name,p.read_bytes(),save_existing=False)
                self.write('etc/apt/trusted.gpg.d/archiveos-ubuntu.gpg',p.read_bytes(),save_existing=False)
            elif p.name=='sources.list':self.write('etc/apt/sources.list',p.read_bytes(),save_existing=False)
            elif p.suffix in ('.list','.sources'):
                self.write('etc/apt/sources.list.d/'+p.name,p.read_bytes(),save_existing=False)
        self.run(['apt-get','-o','APT::Update::Error-Mode=any','update'])
    def remove_flatpak_firefox(self):
        if not shutil.which('flatpak'):return
        scopes=[(['flatpak','--system'],'system')]
        for user in pwd.getpwall():
            if not 1000<=user.pw_uid<60000 or not user.pw_dir.startswith('/home/'):continue
            home=self.target(user.pw_dir.lstrip('/'))
            if not home.is_dir() or home.is_symlink():continue
            # Use the installation owner; never mutate a user's Flatpak files as root.
            prefix=['runuser','-u',user.pw_name,'--','env','-u','FLATPAK_USER_DIR',
                    '-u','DBUS_SESSION_BUS_ADDRESS','HOME='+user.pw_dir,
                    'XDG_DATA_HOME='+user.pw_dir+'/.local/share',
                    'XDG_CONFIG_HOME='+user.pw_dir+'/.config',
                    'XDG_CACHE_HOME='+user.pw_dir+'/.cache',
                    'XDG_RUNTIME_DIR=/run/user/'+str(user.pw_uid),'flatpak','--user']
            if (home/'.local/share/flatpak').is_dir():scopes.append((prefix,user.pw_name))
        for prefix,owner in scopes:
            def refs():
                output=self.run([*prefix,'list','--app','--columns=ref'],capture=True).stdout
                return ['app/'+r.strip().removeprefix('app/') for r in output.splitlines() if re.fullmatch(r'(?:app/)?org\.mozilla\.firefox/[^/\s]+/[^/\s]+',r.strip())]
            installed=refs()
            for ref in installed:
                self.detail('Flatpak Firefox kaldırılıyor','Removing Flatpak Firefox',owner+' / '+ref)
                self.run([*prefix,'uninstall','--app','--noninteractive','-y','--no-related',ref])
            if installed and refs():raise RuntimeError('Flatpak Firefox removal could not be verified: '+owner)

    def upgrade(self):
        self.progress.stage(20,self.t['upgrade'])
        options=['-y','--no-remove','-o','Dpkg::Options::=--force-confdef','-o','Dpkg::Options::=--force-confold']
        self.run(['apt-get',*options,'upgrade','--with-new-pkgs'])
        # Dependency transitions (e.g. Plasma6 -> Plasma7 libraries) need full resolution.
        plan=self.run(['apt-get','-s','dist-upgrade'],capture=True,env={**os.environ,'LC_ALL':'C'}).stdout
        guard_upgrade_plan(plan)
        (self.backup/'apt-transition-plan.txt').write_text(plan)
        full_options=[x for x in options if x!='--no-remove']
        self.run(['apt-get',*full_options,'dist-upgrade'])
        self.run(['apt-get','check'])
        self.run(['apt-get','clean'])
    def apps(self):
        self.progress.stage(85,self.t['apps'])
        options=['-y','--no-remove','-o','Dpkg::Options::=--force-confdef','-o','Dpkg::Options::=--force-confold']
        files=[str(self.bundle/'programs'/p['file']) for p in self.m['packages']]
        self.run(['apt-get',*options,'install','maliit-keyboard','qt6-virtualkeyboard-plugin','qml6-module-qtquick-virtualkeyboard',*files])
        self.run(['apt-get','check'])
        audit=self.run(['dpkg','--audit'],capture=True).stdout.strip()
        if audit:raise RuntimeError('dpkg audit: '+audit)
        self.run(['apt-get','clean'])
        self.remove_flatpak_firefox()
    def consolidate_splash(self):
        base='usr/share/plasma/look-and-feel/'
        shared=base+SPLASH_ID
        source=self.target(base+'org.archiveos.desktop/contents/splash')
        if not (source/'Splash.qml').is_file():source=self.target(base+LEGACY_SPLASH_ID+'/contents/splash')
        if not (source/'Splash.qml').is_file():raise RuntimeError('ArchiveOS splash source missing')
        assets={p.relative_to(source).as_posix():p.read_bytes() for p in sorted(source.rglob('*')) if p.is_file()}
        for name,data in assets.items():self.write(shared+'/contents/splash/'+name,data)
        shares=['usr/share','usr/local/share','etc/skel/.local/share']
        configs=['etc/xdg/ksplashrc','etc/skel/.config/ksplashrc','usr/share/archiveos-default-settings/ksplashrc']
        for user in pwd.getpwall():
            if not 1000<=user.pw_uid<60000 or not user.pw_dir.startswith('/home/'):continue
            home=self.target(user.pw_dir.lstrip('/'))
            if home.is_dir() and not home.is_symlink():
                shares.append(user.pw_dir.lstrip('/')+'/.local/share')
                configs.extend(user.pw_dir.lstrip('/')+'/.config/'+p for p in ('ksplashrc','kdedefaults/ksplashrc'))
        def rewrite(rel):
            p=self.target(rel)
            if not p.is_file() or p.is_symlink():return
            text=p.read_text();fixed=shared_splash_config(text)
            if fixed!=text:
                info=p.stat();self.write(rel,fixed.encode(),info.st_mode&0o777)
                os.chown(p,info.st_uid,info.st_gid)
        for share in shares:
            root=share+'/plasma/look-and-feel/'
            self.save(root+LEGACY_SPLASH_ID,move=True)
            for theme in ('org.archiveos.desktop','org.archiveos-dark.desktop'):
                # A partial local package shadows the complete system package.
                # Removing only its splash hides the system animation from KDE.
                if share!='usr/share':
                    self.save(root+theme,move=True)
                    continue
                if theme!=SPLASH_ID:
                    self.save(root+theme+'/contents/splash',move=True)
                rewrite(root+theme+'/contents/defaults')
        for rel in configs:rewrite(rel)

    def repair_sddm_keyboard(self):
        # sddm.conf overrides conf.d; read the effective compositor settings.
        import configparser
        cfg=configparser.ConfigParser(interpolation=None,strict=False)
        paths=sorted(self.target('usr/lib/sddm/sddm.conf.d').glob('*.conf'))
        paths+=sorted(self.target('etc/sddm.conf.d').glob('*.conf'))
        paths.append(self.target('etc/sddm.conf'))
        cfg.read([str(p) for p in paths])
        content='[General]\nInputMethod=qtvirtualkeyboard\n'
        if cfg.get('General','DisplayServer',fallback='x11').lower()=='wayland':
            command=cfg.get('Wayland','CompositorCommand',fallback='')
            args=shlex.split(command)
            if not args or Path(args[0]).name!='kwin_wayland':
                raise RuntimeError('Cannot repair SDDM keyboard for a non-KWin Wayland compositor')
            if '--inputmethod' not in args and not any(a.startswith('--inputmethod=') for a in args):
                args+=['--inputmethod','/usr/bin/maliit-keyboard']
            content+='\n[Wayland]\nCompositorCommand='+shlex.join(args)+'\n'
            # Main config has precedence over conf.d; update only this setting there.
            main=self.target('etc/sddm.conf')
            if main.is_file():
                own=configparser.ConfigParser(interpolation=None,strict=False);own.optionxform=str
                own.read(main)
                if own.has_option('Wayland','CompositorCommand'):
                    own.set('Wayland','CompositorCommand',shlex.join(args))
                    import io
                    output=io.StringIO();own.write(output)
                    self.write('etc/sddm.conf',output.getvalue().encode())
        self.write('etc/sddm.conf.d/zzzz-archiveos-keyboard.conf',content.encode())

    def repair_session_exit(self):
        # Plasma 6.4 stops plasma-workspace.target. WARP's BindsTo keeps
        # graphical-session.target alive unless its tray follows that stop too.
        if self.target('usr/lib/systemd/user/warp-taskbar.service').is_file():
            self.write('etc/systemd/user/warp-taskbar.service.d/50-archiveos-session.conf',
                       b'[Unit]\nPartOf=graphical-session.target plasma-workspace.target\n')


    def overlay(self):
        self.progress.stage(50,self.t['branding'])
        # Replace complete ArchiveOS asset directories, retaining the previous generation.
        for rel in self.m['source_roots']:
            p=self.target(rel)
            if p.is_dir():self.save(rel,move=True)
        with tarfile.open(self.bundle/'archiveos-overlay.tar.gz','r:gz') as tar:
            members=tar.getmembers();total=len(members)
            last_percent=50
            for index,m in enumerate(members,1):
                p=self.target(m.name)
                if m.isdir():
                    p.mkdir(parents=True,exist_ok=True)
                    self.detail('Dizin hazırlanıyor','Preparing directory',m.name)
                elif m.issym():
                    self.save(m.name);p.parent.mkdir(parents=True,exist_ok=True);p.unlink(missing_ok=True);p.symlink_to(m.linkname)
                    self.detail('Bağlantı uygulanıyor','Applying link',m.name)
                else:self.write(m.name,tar.extractfile(m).read(),m.mode&0o777)
                percent=50+int(30*index/total)
                if percent!=last_percent or index==total:
                    self.progress.stage(percent,self.t['branding']+f' ({index}/{total})');last_percent=percent
        self.consolidate_splash()
        self.repair_sddm_keyboard()
        self.repair_session_exit()
        # Switch the default BEFORE deleting the old Ubuntu themes/alternatives.
        theme='/usr/share/plymouth/themes/ArchiveOS/ArchiveOS.plymouth'
        # Keep a working text plugin under ArchiveOS ownership, without vendor theme dirs.
        text_theme='/usr/share/plymouth/themes/ArchiveOS-Text/ArchiveOS-Text.plymouth'
        self.write(text_theme.lstrip('/'),b'[Plymouth Theme]\nName=ArchiveOS Text\nDescription=ArchiveOS boot text fallback\nModuleName=details\n')
        hook=self.target('usr/share/initramfs-tools/hooks/plymouth')
        if hook.is_file():
            content=hook.read_text()
            # Ubuntu's hook unconditionally copies these two vendor directories.
            # Make those copies optional BEFORE removing the directories.
            for folder in ('details','text'):
                line=f'cp -dRp "${{THEMES}}/{folder}" "${{DESTDIR}}/${{THEMES}}"'
                content=content.replace('\n'+line+'\n',f'\nif [ -d "${{THEMES}}/{folder}" ]; then {line}; fi\n')
            self.write('usr/share/initramfs-tools/hooks/plymouth',content.encode(),hook.stat().st_mode&0o777)
        for name,path in [('default.plymouth',theme),('text.plymouth',text_theme)]:
            self.run(['update-alternatives','--install','/usr/share/plymouth/themes/'+name,name,path,'100'])
            self.run(['update-alternatives','--set',name,path])
            query=self.run(['update-alternatives','--query',name],capture=True).stdout
            for old in re.findall(r'^Alternative: (.*)$',query,re.M):
                if 'ubuntu' in old.casefold() or PurePosixPath(old).parent.name in PLYMOUTH_REMOVE:self.run(['update-alternatives','--remove',name,old])
        themes=self.root/'usr/share/plymouth/themes'
        for p in themes.iterdir():
            if 'ubuntu' in p.name.casefold() or p.name in PLYMOUTH_REMOVE:
                self.save(p.relative_to(self.root).as_posix(),move=True)
        self.cleanup_branding()
        # All Ubuntu-named logo aliases must use ArchiveOS artwork (upstream hook compatibility).
        for base in ['usr/share/pixmaps','usr/share/icons/hicolor']:
            p=self.root/base
            for logo in list(p.rglob('*')) if p.exists() else []:
                if logo.is_file() and re.match(r'(ubuntu|kubuntu)[-_]?(logo|icon)',logo.name,re.I):
                    if logo.suffix=='.png':data=(self.root/'usr/share/pixmaps/archiveos.png').read_bytes()
                    elif logo.suffix=='.svg':
                        import base64
                        encoded=base64.b64encode((self.root/'usr/share/pixmaps/archiveos.png').read_bytes()).decode()
                        data=('<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256"><image width="256" height="256" href="data:image/png;base64,'+encoded+'"/></svg>').encode()
                    else:continue
                    self.write(logo.relative_to(self.root).as_posix(),data)
        # Keep kernel/disk parameters, normalize only the splash flags.
        command=". /etc/default/grub; for f in /etc/default/grub.d/*.cfg; do [ ! -f \"$f\" ] || . \"$f\"; done; printf '%s\\n%s\\n' \"$GRUB_CMDLINE_LINUX\" \"$GRUB_CMDLINE_LINUX_DEFAULT\""
        values=self.run(['bash','-c',command],capture=True).stdout.splitlines()
        if len(values)!=2:raise RuntimeError('Cannot read GRUB kernel parameters')
        def clean(value):return ' '.join(shlex.quote(x) for x in shlex.split(value) if x not in ('splash','nosplash','rhgb') and not x.startswith(('plymouth.enable=','rd.plymouth=')))
        cmdline=clean(values[0]);defaults=clean(values[1]);defaults=(defaults+' splash').strip()
        cfg='GRUB_DISTRIBUTOR="ArchiveOS"\nGRUB_CMDLINE_LINUX='+shlex.quote(cmdline)+'\nGRUB_CMDLINE_LINUX_DEFAULT='+shlex.quote(defaults)+'\n'
        self.write('etc/default/grub.d/zzzz-archiveos-branding.cfg',cfg.encode())
        shell=self.root/'etc/bash.bashrc'
        if shell.exists():self.write('etc/bash.bashrc',normalize_fastfetch(shell.read_text(),system=True).encode())
        skel=self.root/'etc/skel/.bashrc'
        if skel.is_file():
            text=skel.read_text();fixed=normalize_fastfetch(text)
            if fixed!=text:self.write('etc/skel/.bashrc',fixed.encode())
        self.write('var/lib/archiveos-update/desktop-generation',(self.backup.name+'\n').encode())
        # Copy only appearance configuration into existing users; no account files.
        for user in pwd.getpwall():
            if not 1000<=user.pw_uid<60000 or not user.pw_dir.startswith('/home/'):continue
            home=self.root/user.pw_dir.lstrip('/')
            if not home.is_dir() or home.is_symlink():continue
            bashrc=self.target((home/'.bashrc').relative_to(self.root).as_posix())
            if bashrc.is_file() and not bashrc.is_symlink():
                text=bashrc.read_text();fixed=normalize_fastfetch(text)
                if fixed!=text:
                    self.write(bashrc.relative_to(self.root).as_posix(),fixed.encode(),bashrc.stat().st_mode&0o777)
                    os.chown(bashrc,user.pw_uid,user.pw_gid)
            for name in ['kdeglobals','plasmarc','ksplashrc']:
                src=self.root/'etc/skel/.config'/name
                dst=home/'.config'/name
                self.write(dst.relative_to(self.root).as_posix(),src.read_bytes());os.chown(dst,user.pw_uid,user.pw_gid)
            os.chown(home/'.config',user.pw_uid,user.pw_gid)
            # User fastfetch overrides should not keep Ubuntu branding.
            dst=home/'.config/fastfetch/config.jsonc'
            self.write(dst.relative_to(self.root).as_posix(),(self.root/'etc/fastfetch/config.jsonc').read_bytes())
            os.chown(dst,user.pw_uid,user.pw_gid);os.chown(dst.parent,user.pw_uid,user.pw_gid)
    def services(self):
        self.progress.stage(90,'Servisler kuruluyor…' if self.lang=='tr' else 'Installing services…')
        for item in self.m.get('services',[]):
            self.write(item['target'],(self.bundle/item['file']).read_bytes())
        self.run(['systemctl','daemon-reload'])
        self.run(['systemctl','--global','enable','aos-update-checker.service'])
        self.install_kernel_cleanup()
    def install_kernel_cleanup(self):
        self.write('usr/local/libexec/archiveos-kernel-cleanup.py',(self.bundle/'helpers/kernel_cleanup.py').read_bytes(),0o755)
        self.write('etc/systemd/system/archiveos-kernel-cleanup.service',b'[Unit]\nDescription=ArchiveOS obsolete kernel cleanup\nAfter=local-fs.target\nStartLimitIntervalSec=0\n\n[Service]\nType=oneshot\nExecStart=/usr/bin/python3 /usr/local/libexec/archiveos-kernel-cleanup.py --apply\nRestart=on-failure\nRestartSec=60\n')
        self.write('etc/systemd/system/archiveos-kernel-cleanup.timer',b'[Unit]\nDescription=ArchiveOS kernel cleanup after boot and APT\n\n[Timer]\nOnBootSec=2min\nOnActiveSec=1min\nUnit=archiveos-kernel-cleanup.service\n\n[Install]\nWantedBy=timers.target\n')
        # APT hooks only schedule the worker: no recursive apt call while dpkg is locked.
        self.write('etc/apt/apt.conf.d/99archiveos-kernel-cleanup',b'DPkg::Post-Invoke { "if [ -d /run/systemd/system ]; then systemctl --no-block restart archiveos-kernel-cleanup.timer >/dev/null 2>&1 || true; fi"; };\n')
        self.run(['systemctl','daemon-reload'])
        self.run(['systemctl','enable','--now','archiveos-kernel-cleanup.timer'])
    def boot(self):
        self.progress.stage(95,self.t['boot'])
        self.run(['update-initramfs','-u','-k','all'])
        self.run(['/usr/bin/python3','/usr/local/libexec/archiveos-kernel-cleanup.py','--apply'])
        self.run(['update-grub'])
    def execute(self):
        self.snapshot();self.repos();self.upgrade();self.overlay();self.apps();self.services();self.boot()
        self.progress.stage(100,self.t['complete'])


def preflight(bundle,m):
    info=read_os();suite=info.get('UBUNTU_CODENAME') or info.get('VERSION_CODENAME')
    if not (info.get('ID')=='ubuntu' or 'ubuntu' in info.get('ID_LIKE','').split()):raise RuntimeError('Ubuntu-based installed system required')
    print('Ubuntu '+str(suite)+' → ISO repositories '+m['ubuntu_codename'],flush=True)
    if (os.stat('/').st_dev,os.stat('/').st_ino)!=(os.stat('/proc/1/root').st_dev,os.stat('/proc/1/root').st_ino):raise RuntimeError('Installed system required; chroot is not supported')
    fs=subprocess.check_output(['findmnt','-n','-o','FSTYPE','/'],text=True).strip()
    if fs in ('overlay','aufs','squashfs') or Path('/run/casper').exists():raise RuntimeError('Live ISO update is not supported')
    for tool in ['timeshift','apt-get','dpkg','plymouth','update-alternatives','update-initramfs','update-grub','systemctl']:
        if not shutil.which(tool):raise RuntimeError('Missing required tool: '+tool)
    if not Path('/etc/timeshift/timeshift.json').is_file():raise RuntimeError('Configure Timeshift before updating')
    plugin_dir=Path(subprocess.check_output(['plymouth','--get-splash-plugin-path'],text=True).strip())
    if not plugin_dir.is_absolute() or not (plugin_dir/'details.so').is_file():
        raise RuntimeError('Plymouth details plugin missing (required by ArchiveOS-Text)')
    audit=subprocess.check_output(['dpkg','--audit'],text=True).strip()
    if audit:raise RuntimeError('Repair dpkg before updating: '+audit)


def reboot_question(bundle,lang):
    user=os.environ.get('SUDO_USER')
    if user and user!='root':
        uid=pwd.getpwnam(user).pw_uid;runtime=Path('/run/user')/str(uid)
        wayland=next(iter(sorted(runtime.glob('wayland-*'))),None)
        # Exclude lock files and detect the actual user's Wayland socket.
        sockets=[p for p in runtime.glob('wayland-*') if stat.S_ISSOCK(p.stat().st_mode)] if runtime.exists() else []
        display=os.environ.get('DISPLAY')
        if sockets or display:
            env={'PATH':'/usr/bin:/bin','HOME':pwd.getpwnam(user).pw_dir,'XDG_RUNTIME_DIR':str(runtime),'DBUS_SESSION_BUS_ADDRESS':'unix:path='+str(runtime/'bus'),'LANG':os.environ.get('LANG','C.UTF-8')}
            if sockets:env.update(WAYLAND_DISPLAY=sockets[0].name,QT_QPA_PLATFORM='wayland')
            elif display:
                env.update(DISPLAY=display,QT_QPA_PLATFORM='xcb')
                authority=os.environ.get('XAUTHORITY')
                if authority:env['XAUTHORITY']=authority
            result=subprocess.run(['runuser','-u',user,'--','env',*[k+'='+v for k,v in env.items()],'/usr/bin/python3','/usr/local/libexec/archiveos-update/reboot.py','--lang',lang])
            if result.returncode==0:return False
            raise RuntimeError('reboot.py failed: '+str(result.returncode))
    if not sys.stdin.isatty():return False
    answer=input(TEXT[lang]['reboot']).strip().lower()
    return answer in (('e','evet') if lang=='tr' else ('y','yes'))


def main():
    p=argparse.ArgumentParser();p.add_argument('--bundle',type=Path,required=True);p.add_argument('--dry-run',action='store_true');p.add_argument('--lang',choices=TEXT);a=p.parse_args()
    lang=a.lang or ('tr' if os.environ.get('LANG','').lower().startswith('tr') else 'en')
    bundle=a.bundle.resolve();m=json.loads((bundle/'manifest.json').read_text());verify(bundle,m)
    if a.dry_run:
        print('ArchiveOS '+m['version']+' / Ubuntu '+m['ubuntu_codename']);print('Checksums and overlay paths: OK')
        print(' → '.join([TEXT[lang][k] for k in ['snapshot','repo','upgrade','branding','apps','boot','complete']]))
        print('Applications → services/ → boot rebuild → reboot.py')
        print('Ubuntu/Kubuntu theme names scanned (Plasma, SDDM, wallpapers, user assets); Kubuntu Website/Restore desktop links removed. ArchiveOS animation kept.');print('No system changes performed.');return
    if os.geteuid()!=0:raise RuntimeError('Run install.sh to request sudo')
    preflight(bundle,m)
    os.environ['DEBIAN_FRONTEND']='noninteractive'
    os.environ['NEEDRESTART_MODE']='l'
    lock_path=Path('/run/lock/archiveos-update.lock');lock=lock_path.open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    backup=Path('/var/backups/archiveos-update')/stamp;backup.mkdir(parents=True,mode=0o700)
    logs=Path('/var/log/archiveos-update');logs.mkdir(exist_ok=True);log=logs/(stamp+'.log');run=Runner(log,Progress(lang,log))
    # Freeze and verify a root-owned private copy before any system mutation.
    with tempfile.TemporaryDirectory(prefix='archiveos-update-',dir='/var/tmp') as temp:
        immutable=Path(temp)/'bundle';shutil.copytree(bundle,immutable,symlinks=True);verify(immutable,m)
        try:
            Updater(immutable,m,Path('/'),backup,run,lang).execute()
            (backup/'completed').write_text('OK\n')
            if reboot_question(immutable,lang):run(['systemctl','reboot'])
        except Exception:
            print(TEXT[lang]['error']+'. '+str(log),file=sys.stderr)
            print('Timeshift snapshot record: '+str(backup/'timeshift-snapshot.txt'),file=sys.stderr);raise
if __name__=='__main__':
    try:main()
    except Exception as e:print(str(e),file=sys.stderr);sys.exit(1)
