import configparser
import os
from pathlib import Path
import pwd
import re
import shutil

ACTION = 'ArchiveStoreUninstall'
DESKTOP = 'archive-store.desktop'
MIMES = ('application/vnd.debian.binary-package', 'application/x-deb')


def set_value(text, section, key, value):
    lines = text.splitlines()
    start = next((i for i,line in enumerate(lines) if line.strip() == '['+section+']'), None)
    if start is None:
        return text.rstrip()+'\n\n['+section+']\n'+key+'='+value+'\n'
    end = next((i for i in range(start+1,len(lines)) if lines[i].startswith('[')),len(lines))
    found = [i for i in range(start+1,end) if lines[i].split('=',1)[0].strip() == key]
    if found:
        lines[found[0]] = key+'='+value
        for i in reversed(found[1:]):lines.pop(i)
    else:lines.insert(end,key+'='+value)
    return '\n'.join(lines)+'\n'


def mime_defaults(text):
    for mime in MIMES:
        text = set_value(text,'Default Applications',mime,DESKTOP+';')
        text = set_value(text,'Added Associations',mime,DESKTOP+';')
        match = re.search(r'(?ms)^\[Removed Associations\]\n(.*?)(?=^\[|\Z)',text)
        if match:
            for line in match[1].splitlines():
                if line.startswith(mime+'='):
                    rest = ';'.join(item for item in line.split('=',1)[1].split(';') if item and item != DESKTOP)
                    text = set_value(text,'Removed Associations',mime,rest+';' if rest else '')
    return text


def uninstall_action(text):
    cfg=configparser.ConfigParser(interpolation=None,strict=False)
    cfg.optionxform=str
    try:
        cfg.read_string(text)
        entry=cfg['Desktop Entry']
    except (KeyError,configparser.Error):return text
    if entry.get('Type') != 'Application' or entry.get('Hidden') == 'true' or entry.get('NoDisplay') == 'true':return text
    actions=[value for value in entry.get('Actions','').split(';') if value and value != ACTION]
    actions.append(ACTION)
    text=set_value(text,'Desktop Entry','Actions',';'.join(actions)+';')
    for key,value in {'Name':'Uninstall with ArchiveStore','Name[tr]':'ArchiveStore ile kaldır','Icon':'archive-store','Exec':'/usr/bin/archive-store --uninstall-desktop %k'}.items():
        text=set_value(text,'Desktop Action '+ACTION,key,value)
    return text


CATEGORY_ICON='/usr/share/icons/hicolor/256x256/categories/archiveos-apps.png'


def category_names(root):
    import xml.etree.ElementTree as ET
    root=Path(root);names={'archiveos-apps.directory'}
    for path in (root/'usr/share/desktop-directories').glob('archiveos-apps*.directory'):names.add(path.name)
    for folder in ('applications-merged','plasma-applications-merged','kf5-applications-merged'):
        for path in (root/'etc/xdg/menus'/folder).glob('archiveos-apps*.menu'):
            try:
                for node in ET.fromstring(path.read_text()).iter('Directory'):
                    name=(node.text or '').strip()
                    if re.fullmatch(r'archiveos-apps(?:-[a-z0-9-]+)?\.directory',name):names.add(name)
            except (OSError,ET.ParseError):continue
    return names


def category_entry(text='',icon=CATEGORY_ICON):
    for key,value in {'Type':'Directory','Name':'ArchiveOS Apps','Name[tr]':'ArchiveOS Apps','Icon':icon}.items():text=set_value(text,'Desktop Entry',key,value)
    return text


def repair_user_category(home,logo_source,system_root=Path('/')):
    """Repair per-user category entries, including orphaned retired-package menu refs."""
    import datetime
    home=Path(home);folder=home/'.local/share/desktop-directories';folder.mkdir(parents=True,exist_ok=True)
    image=home/'.local/share/icons/hicolor/256x256/categories/archiveos-apps.png';image.parent.mkdir(parents=True,exist_ok=True)
    backup=home/'.local/state/archiveos-menu-repair'/datetime.datetime.now().strftime('%Y%m%d-%H%M%S');changed=[]
    source=Path(logo_source).read_bytes()
    if not image.exists() or image.read_bytes()!=source:
        if image.exists():backup.mkdir(parents=True,exist_ok=True);shutil.copy2(image,backup/'archiveos-apps.png')
        image.write_bytes(source);image.chmod(0o644)
    names=category_names(system_root)|{p.name for p in folder.glob('archiveos-apps*.directory')}
    for name in sorted(names):
        path=folder/name
        if path.is_symlink():continue
        text=path.read_text() if path.exists() else '';updated=category_entry(text,str(image))
        if text==updated:continue
        if path.exists():backup.mkdir(parents=True,exist_ok=True);shutil.copy2(path,backup/name)
        path.write_text(updated);path.chmod(0o644);changed.append(str(path))
    return changed


def apply(root=Path('/'), accounts=None, backup=None, mime_only=False):
    root=Path(root)
    changes=[]
    def write(path,text,owner=None):
        if path.is_symlink() or any(parent.is_symlink() for parent in path.parents if parent != root and parent.is_relative_to(root)):return
        old=path.read_text() if path.is_file() else ''
        if old == text:return
        mode=path.stat().st_mode & 0o777 if path.exists() else 0o644
        if backup is not None and path.is_file():
            saved=Path(backup)/path.relative_to(root)
            if not saved.exists():saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,saved)
        missing=[]
        parent=path.parent
        while not parent.exists():missing.append(parent);parent=parent.parent
        path.parent.mkdir(parents=True,exist_ok=True)
        if owner is not None and os.geteuid() == 0:
            for folder in missing:os.chown(folder,*owner)
        path.write_text(text);path.chmod(mode)
        if owner is not None and os.geteuid() == 0:
            os.chown(path,*owner)
        changes.append(str(path.relative_to(root)))
    names=category_names(root)
    if not mime_only:
        for name in sorted(names):
            path=root/'usr/share/desktop-directories'/name
            if not path.is_symlink():write(path,category_entry(path.read_text() if path.exists() else ''))
        for base in ('usr/share/applications','usr/local/share/applications','var/lib/flatpak/exports/share/applications','var/lib/snapd/desktop/applications'):
            for path in (root/base).glob('*.desktop'):
                if path.name == DESKTOP:continue
                if path.is_symlink():
                    try:
                        resolved=path.resolve(strict=True)
                        if not resolved.is_relative_to(root.resolve()):continue
                        path=resolved
                    except OSError:continue
                write(path,uninstall_action(path.read_text()))
    homes=[(root/'etc/skel',None)]
    if accounts is None:accounts=pwd.getpwall()
    for account in accounts:
        if 1000 <= account.pw_uid < 60000 and account.pw_dir.startswith('/home/'):
            home=root/account.pw_dir.lstrip('/')
            if home.is_dir() and not home.is_symlink():homes.append((home,(account.pw_uid,account.pw_gid)))
    for home,owner in homes:
        for name in ('mimeapps.list','kde-mimeapps.list'):
            path=home/'.config'/name
            write(path,mime_defaults(path.read_text() if path.is_file() and not path.is_symlink() else ''),owner)
        launcher=home/'.local/share/applications'/DESKTOP
        if launcher.is_file() and not launcher.is_symlink():
            text=set_value(launcher.read_text(),'Desktop Entry','StartupWMClass','archive-store')
            if 'X-ArchiveOS-ManagedIcon=true' in text:
                cfg=configparser.ConfigParser(interpolation=None,strict=False);cfg.read(root/'usr/share/applications'/DESKTOP)
                text=set_value(text,'Desktop Entry','Icon',cfg.get('Desktop Entry','Icon',fallback='archive-store'))
            write(launcher,text,owner)
        if not mime_only:
            user_names=names|{p.name for p in (home/'.local/share/desktop-directories').glob('archiveos-apps*.directory')}
            for name in sorted(user_names):
                path=home/'.local/share/desktop-directories'/name
                if not path.is_symlink():write(path,category_entry(path.read_text() if path.exists() else ''),owner)
            for path in (home/'.local/share/applications').glob('*.desktop'):
                if path.is_symlink():continue
                if path.name==DESKTOP:
                    text=path.read_text()
                    if 'X-ArchiveOS-ManagedIcon=true' in text:
                        cfg=configparser.ConfigParser(interpolation=None,strict=False);cfg.read(root/'usr/share/applications'/DESKTOP)
                        icon=cfg.get('Desktop Entry','Icon',fallback='archive-store')
                        write(path,set_value(text,'Desktop Entry','Icon',icon),owner)
                else:write(path,uninstall_action(path.read_text()),owner)
    for name in ('mimeapps.list','kde-mimeapps.list'):
        path=root/'etc/xdg'/name
        write(path,mime_defaults(path.read_text() if path.is_file() and not path.is_symlink() else ''))
    return changes


if __name__ == '__main__':
    import argparse,json
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path('/'))
    parser.add_argument('--backup',type=Path)
    parser.add_argument('--mime-only',action='store_true')
    args=parser.parse_args()
    print(json.dumps(apply(args.root,backup=args.backup,mime_only=args.mime_only),ensure_ascii=False))
